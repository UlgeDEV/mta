--##################################
--## Script feito por zJoaoFtw_   ##
--##################################

config = {
    ["Mensagem Start"] = true, --Caso esteja false ele não irá aparecer a mensagem!
    ["Marker's"] = {
        {1501, -1286, 15, "dealership"},
        {1504, -1286, 15, "dealership"},
        {1359.406, -1651.272, 13.442-0.9, "garage"}, -- 3
        {1715.376, -1880.222, 13.566-0.9, "garage"}, -- 4
        {1978.819, -1274.981, 23.82-0.9, "garage"}, -- 5
        {428.408, -1794.228, 5.547-0.9, "garage"}, -- 6 
        {2145.54, 1398.49, 10.813-0.9, "garage"}, -- 7 LV
        {-2591.941, 645.31, 27.812-0.9, "garage"}, -- 8 SF
        {1929.199, -1445.97, 13.491-0.9, "garage"}, -- 9 LS
        {898.116, -1477.49, 13.556-0.9, "garage"}, -- 10 LS
        {892.923, -1658.041, 13.547-0.9, "garage"}, -- 11 LS
        {1516.076, -1180.459, 24.071-0.9, "garage"}, -- 12 LS
        {347.99, -1359.954, 14.508-0.9, "garage"}, -- 13 LS 
        {-1654.061, 1316.497, 7.039-0.9, "garage"}, -- 14 SF
        {1613.725, -1089.725, 24.128-0.9, "detran"},
    },
    ["Vehicles"] = {
        ["car"] = {
            {
                Name = "Chevete 1.6S",
                Price = {money = 10000, points = 5, rent = 1000},
                ID = 602,
            },
            {
                Name = "Fiat Uno",
                Price = {money = 20000, points = 7, rent = 2000},
                ID = 496,
            },
            {
                Name = "Corsa",
                Price = {money = 40000, points = 8, rent = 4000},
                ID = 445,
            },
            {
                Name = "Saveiro",
                Price = {money = 80000, points = 10, rent = 8000},
                ID = 589,
            },
            {
                Name = "Subaru",
                Price = {money = 150000, points = 15, rent = 15000},
                ID = 405,
            },
            {
                Name = "Golf GTI",
                Price = {money = 350000, points = 20, rent = 35000},
                ID = 561,
            },
            {
                Name = "Toyota Corolla",
                Price = {money = 450000, points = 25, rent = 45000},
                ID = 585,
            },
            {
                Name = "Volkswagen Jetta VW",
                Price = {money = 550000, points = 30, rent = 55000},
                ID = 560,
            },
            {
                Name = "Mustang Shelby",
                Price = {money = 850000, points = 35, rent = 85000},
                ID = 507,
            },
            {
                Name = "Urus",
                Price = {money = 1250000, points = 50, rent = 125000},
                ID = 540,
            },
            {
                Name = "BMW X6",
                Price = {money = 2750000, points = 80, rent = 275000},
                ID = 421,
            },
            {
                Name = "Evoque",
                Price = {money = 3500000, points = 100, rent = 350000},
                ID = 426,
            },
            {
                Name = "Jaguar F-Pace",
                Price = {money = 5500000, points = 120, rent = 550000},
                ID = 604,
            },
            {
                Name = "BMW I8",
                Price = {money = 10000000, points = 130, rent = 1000000},
                ID = 439,
            },
            {
                Name = "Porsche 911",
                Price = {money = 20000000, points = 150, rent = 2000000},
                ID = 527,
            },
            {
                Name = "GTR R34",
                Price = {money = 30000000, points = 180, rent = 3000000},
                ID = 529,
            },
            {
                Name = "Lamborghini Huracan",
                Price = {money = 40000000, points = 200, rent = 4000000},
                ID = 451,
            },
        },
        ["motorbike"] = {
            {
                Name = "Honda Pop",
                Price = {money = 10000, points = 3, rent = 1000},
                ID = 462,
            },
            {
                Name = "Hornet",
                Price = {money = 80000, points = 15, rent = 8000},
                ID = 522,
            },
            {
                Name = "MT-03",
                Price = {money = 120000, points = 25, rent = 12000},
                ID = 521,
            },
        },
        ["trucks"] = {
            {
                Name = "SCANIA 113",
                Price = {money = 7500000, points = 75, rent = 750000},
                ID = 514,
            },
        },
        ["boats"] = {
        },
        ["helicopters"] = {
        },
    },
    ["VIP's"] = {
        ["Vanish"] = {
            {
                Name = "BMW 750Li",
                ID = 550,
            },
            {
                Name = "XJ6",
                ID = 461,
            },
        },
        ["OMO"] = {
            {
                Name = "Toyota SUPRA 90",
                ID = 401,
            },
            {
                Name = "XJ6",
                ID = 461,
            },
        },
        ["Ype"] = {
            {
                Name = "Honda Civic",
                ID = 466,
            },
            {
                Name = "XJ6",
                ID = 461,
            },
        },
        ["Brilhante"] = {
            {
                Name = "Panto",
                ID = 587,
            },
            {
                Name = "XJ6",
                ID = 461,
            },
        },
    },
    ["Data garage's"] = {
        [3] = {
            Pos = {1366.436, -1651.53, 13.383},
            Rotation = {0, 0, 272.407},
        },
        [4] = {
            Pos = {1714.996, -1870.196, 13.567},
            Rotation = {0, 0, 3.54},
        },
        [5] = {
            Pos = {1981.674, -1274.381, 23.82},
            Rotation = {0, 0, 186},
        },
        [6] = {
            Pos = {428.376, -1788.052, 5.547},
            Rotation = {0, 0, 8.149},
        },
        [7] = {
            Pos = {2142.156, 1398.03, 10.813},
            Rotation = {0, 0, 7.836},
        },
        [8] = {
            Pos = {-2591.321, 640.144, 27.812},
            Rotation = {0, 0, 90.196},
        },
        [9] = {
            Pos = {1929.199, -1445.97, 13.491},
            Rotation = {0, 0, 90.196},
        },
        [10] = {
            Pos = {898.547, -1483.383, 13.561},
            Rotation = {0, 0, 90.196},
        },
        [11] = {
            Pos = {888.01, -1658.066, 13.547},
            Rotation = {0, 0, 90.196},
        },
        [12] = {
            Pos = {1522.063, -1179.634, 24.048},
            Rotation = {0, 0, 90.196},
        },
        [13] = {
            Pos = {345.818, -1355.386, 14.508},
            Rotation = {0, 0, 90.196},
        },
        [14] = {
            Pos = {-1652.104, 1311.422, 7.039},
            Rotation = {0, 0, 144.744},
        },
    },
    ["Color's"] = {
        {255, 0, 0}, --ROJO
        {255, 238, 0},--AMARILLO
        {174, 255, 0}, --VERDE CLARO
        {72, 2, 125},--VIOLETA
        {250, 67, 235},--ROSA
    },
}