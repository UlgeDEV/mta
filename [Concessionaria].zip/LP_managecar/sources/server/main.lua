addEventHandler("onResourceStart", resourceRoot,
function()
    if config["Mensagem Start"] then
        outputDebugString("["..getResourceName(getThisResource()).."] Startado com sucesso, qualquer bug contacte zJoaoFtw_#5562!")
    end
end)

addEvent("JOAO.manageCarMANAGE", true)
addEventHandler("JOAO.manageCarMANAGE", root,
function(player, typeManage)
    local vehicle = getPedOccupiedVehicle(player)
    if not vehicle then return end
    if typeManage == "trancar" then
        local identity = (getElementData(vehicle, 'JOAO.identityCar') or false)
        if not identity then return end
        local data = exports["TB_inventario"]:getItemDataByData(player, identity)
        if not (getVehicleController(vehicle) == player) then return notifyS(player, "Você não é o motorista!", "error") end
        if data then 
            if (isVehicleLocked(vehicle)) then 
                setVehicleLocked(vehicle, false)
                setElementData(vehicle, "veh:lock", false)
				setTimer(lightsEfffect, 150, 4, vehicle)
                triggerClientEvent(player, "JOAO.playSoundMANAGE", player, "files/sounds/locked.mp3")
                notifyS(player, "Veiculo destrancado!", "info")
            else 
                setVehicleLocked(vehicle, true)
                setElementData(vehicle, "veh:lock", true)
				setTimer(lightsEfffect, 150, 4, vehicle)
                triggerClientEvent(player, "JOAO.playSoundMANAGE", player, "files/sounds/unlocked.mp3")
                notifyS(player, "Veiculo trancado!", "info")
            end
        end
    elseif typeManage == "motor" then
        if (isVehicleOnGround(vehicle)) then 
            if (getVehicleEngineState(vehicle)) then 
                setVehicleEngineState(vehicle, false)
                notifyS(player, "Veiculo desligado!", "info")
            else
                setVehicleEngineState(vehicle, true)
                triggerClientEvent(player, "JOAO.playSoundMANAGE", player, "files/sounds/starter.mp3")
                notifyS(player, "Veiculo ligado!", "info")
            end
        else
            notifyS(player, "Veiculo deve estar no chão!", "error")
        end

    elseif typeManage == "freio" then
        if not (getVehicleController(vehicle) == player) then return notifyS(player, "Você não é o motorista!", "error") end 
        if (isVehicleOnGround(vehicle)) then 
            if (isElementFrozen(vehicle)) then 
                setElementFrozen(vehicle, false) 
                setVehicleEngineState(vehicle, false)
                notifyS(player, "Freio de mão desativado!", "info")
            else 
                setElementFrozen(vehicle, true) 
                notifyS(player, "Freio de mão ativado!", "info")
            end
        else
            notifyS(player, "Seu veiculo não está no chão!", "error")
        end
    elseif typeManage == "farol" then
        if not (getVehicleController(vehicle) == player) then return notifyS(player, "Você não é o motorista!", "error") end 
        if (getVehicleOverrideLights(vehicle) == 2) then 
            setVehicleOverrideLights(vehicle, 1)
            notifyS(player, "Faróis desligados!", "info")
        else
            setVehicleOverrideLights(vehicle, 2) 
            notifyS(player, "Faróis ligados!", "info")
        end
        triggerClientEvent(player, "JOAO.playSoundMANAGE", player, "files/sounds/lightswitch.mp3")
    elseif typeManage == "cinto" then
        if (getElementData(player, "belt")) then 
            removeElementData(player, "belt")
            notifyS(player, "Você retirou o cinto de segurança!", "success")
            triggerClientEvent(player, "JOAO.playSoundMANAGE", player, "files/sounds/ovki.mp3")
        else
            triggerClientEvent(player, "JOAO.playSoundMANAGE", player, "files/sounds/ovbe.mp3")
            setElementData(player, "belt", true)
            notifyS(player, "Você colocou o cinto de segurança!", "success")
        end
    end
end)

addEvent("JOAO.manageVehicleDoors", true)
addEventHandler("JOAO.manageVehicleDoors", root,
function(player, typeOpen)
    local vehicle = getPedOccupiedVehicle(player)
    if vehicle then
        if typeOpen == "left_door_primary" then
            if getVehicleDoorOpenRatio(vehicle, 2) == 0 then
                setVehicleDoorOpenRatio(vehicle, 2, 1, 2500)
            else
                setVehicleDoorOpenRatio(vehicle, 2, 0, 2500)
            end
        elseif typeOpen == "left_door_secondary" then
            if getVehicleDoorOpenRatio(vehicle, 4) == 0 then
                setVehicleDoorOpenRatio(vehicle, 4, 1, 2500)
            else
                setVehicleDoorOpenRatio(vehicle, 4, 0, 2500)
            end
        elseif typeOpen == "right_door_primary" then
            if getVehicleDoorOpenRatio(vehicle, 3) == 0 then
                setVehicleDoorOpenRatio(vehicle, 3, 1, 2500)
            else
                setVehicleDoorOpenRatio(vehicle, 3, 0, 2500)
            end
        elseif typeOpen == "right_door_secondary" then
            if getVehicleDoorOpenRatio(vehicle, 5) == 0 then
                setVehicleDoorOpenRatio(vehicle, 5, 1, 2500)
            else
                setVehicleDoorOpenRatio(vehicle, 5, 0, 2500)
            end
        elseif typeOpen == "hood" then
            if getVehicleDoorOpenRatio(vehicle, 0) == 0 then
                setVehicleDoorOpenRatio(vehicle, 0, 1, 2500)
            else
                setVehicleDoorOpenRatio(vehicle, 0, 0, 2500)
            end
        elseif typeOpen == "trunk" then
            if getVehicleDoorOpenRatio(vehicle, 1) == 0 then
                setVehicleDoorOpenRatio(vehicle, 1, 1, 2500)
            else
                setVehicleDoorOpenRatio(vehicle, 1, 0, 2500)
            end
        end
    end
end)

limitSuspensionUp = {}
limitSuspensionDown = {}
suspensionCalcUp = {}
suspensionCalcDown = {}

addEvent("JOAO.suspensionManage", true)
addEventHandler("JOAO.suspensionManage", root,
function(player, manageSuspension)
    if manageSuspension then
        local vehicle = getPedOccupiedVehicle(player)
        if not vehicle then return end
        local suspension = (getVehicleHandling(vehicle)['suspensionLowerLimit'])
        local handlingPadrao = exports["vanish_handling"]:getSuspension(getElementModel(vehicle))
        local subSuspension = string.sub(suspension, 1, 5)
        local subHandling = string.sub(handlingPadrao, 1, 5)
        if manageSuspension == "up" then
            if tonumber(subSuspension) <= tonumber(subHandling-0.2) then return end
            setVehicleHandling(vehicle, "suspensionLowerLimit", suspension - 0.11)
        elseif manageSuspension == "down" then
            if tonumber(subSuspension) >= tonumber(subHandling+0.2) then return end
            setVehicleHandling(vehicle, "suspensionLowerLimit", suspension + 0.11)
        end
    end
end)

addEventHandler("onVehicleStartEnter", root, 
    function(player, _, targetPlayer)
        if (getElementData(source, "veh:lock")) then 
            cancelEvent() 
            triggerClientEvent(player, "JOAO.playSoundMANAGE", player, "files/sounds/lockin.mp3")
            notifyS(player, "Veiculo trancado!", "error") 
            if targetPlayer and isElement(targetPlayer) then 
                notifyS(targetPlayer, "Um jogador está tentando roubar seu veículo!", "warning")
            end 
        end 
    end
)

addEventHandler("onVehicleStartExit", root, 
    function(player, _, targetPlayer)
        if targetPlayer and isElement(targetPlayer) then 
            if getElementData(source, "veh:lock") then 
                cancelEvent()
                notifyS(targetPlayer, "O veículo está trancado!", "error") 
                notifyS(player, "Um jogador está tentando roubar seu veículo!", "info")
            else 
                setElementData(player, "belt", false)
            end 
        else 
            if source and isElement(source) and player and isElement(player) and (getElementData(source, "veh:lock")) then 
                cancelEvent() 
                triggerClientEvent(player, "JOAO.playSoundMANAGE", player, "files/sounds/lockin.mp3")
                notifyS(player, "Veiculo trancado!", "error") 
            end 

            if player and isElement(player) and (getElementData(player, "belt")) then 
                cancelEvent() 
                notifyS(player, "Você está usando o cinto, retire ele para sair do veiculo!", "error")
            end
        end 
    end
)

function lightsEfffect(veh)
	if veh and isElement(veh) and getElementType(veh) == "vehicle" then 
		lights = getVehicleOverrideLights(veh)
		if (lights == 2) then
			setVehicleOverrideLights(veh, 1)
		else
			setVehicleOverrideLights(veh, 2)
		end
	end 
end