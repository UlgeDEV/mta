local font = dxCreateFont("files/fonts/medium.ttf", 8)
local font2 = dxCreateFont("files/fonts/medium.ttf", 8)

myInv = {}
targetInv = {}

Slots = {
    {206, 298, 57, 57},
    {269, 298, 57, 57},
    {332, 298, 57, 57},
    {395, 298, 57, 57},
    {458, 298, 57, 57},
    {521, 298, 57, 57},
    {584, 298, 57, 57},
    
    {206, 361, 57, 57},
    {269, 361, 57, 57},
    {332, 361, 57, 57},
    {395, 361, 57, 57},
    {458, 361, 57, 57},
    {521, 361, 57, 57},
    {584, 361, 57, 57},
    
    {206, 424, 57, 57},
    {269, 424, 57, 57},
    {332, 424, 57, 57},
    {395, 424, 57, 57},
    {458, 424, 57, 57},
    {521, 424, 57, 57},
    {584, 424, 57, 57},
}

SlotsTarget = {
    {725, 298, 57, 57},
    {788, 298, 57, 57},
    {851, 298, 57, 57},
    {914, 298, 57, 57},
    {977, 298, 57, 57},
    {1040, 298, 57, 57},
    {1103, 298, 57, 57},
    
    {725, 361, 57, 57},
    {788, 361, 57, 57},
    {851, 361, 57, 57},
    {914, 361, 57, 57},
    {977, 361, 57, 57},
    {1040, 361, 57, 57},
    {1103, 361, 57, 57},
    
    {725, 424, 57, 57},
    {788, 424, 57, 57},
    {851, 424, 57, 57},
    {914, 424, 57, 57},
    {977, 424, 57, 57},
    {1040, 424, 57, 57},
    {1103, 424, 57, 57},
}

edits = {}

function dx()
    if window == "index" then
        local pesoAtual = math.floor((getElementData(localPlayer, "pesoInv") or 0)) 
        local pesoMax = (getElementData(localPlayer, "pesoMax") or config["Weight Template"])
        dxDrawImage(189, 232, 988, 304, "files/imgs/base.png")
        if (isMouseInPosition(535, 265, 10, 14) and not manageEdits) or aba == 1 then
            dxDrawImage(535, 265, 10, 14, "files/imgs/backpack.png", 0, 0, 0, tocolor(173, 146, 255))
        else
            dxDrawImage(535, 265, 10, 14, "files/imgs/backpack.png", 0, 0, 0, tocolor(255, 255, 255, 20))
        end
        if (isMouseInPosition(559, 266, 11, 12) and not manageEdits) or aba == 2 then
            dxDrawImage(559, 266, 11, 12, "files/imgs/keys.png", 0, 0, 0, tocolor(173, 146, 255))
        else
            dxDrawImage(559, 266, 11, 12, "files/imgs/keys.png", 0, 0, 0, tocolor(255, 255, 255, 20))
        end
        if (isMouseInPosition(583, 266, 16, 12) and not manageEdits) or aba == 3 then
            dxDrawImage(583, 266, 16, 12, "files/imgs/identity.png", 0, 0, 0, tocolor(173, 146, 255))
        else
            dxDrawImage(583, 266, 16, 12, "files/imgs/identity.png", 0, 0, 0, tocolor(255, 255, 255, 20))
        end
		if (isMouseInPosition(607, 257, 18, 24) and not manageEdits) or aba == 4 then
            dxDrawImage(607, 257, 18, 24, "files/imgs/ilegais.png", 0, 0, 0, tocolor(173, 146, 255))
        else
            dxDrawImage(607, 257, 18, 24, "files/imgs/ilegais.png", 0, 0, 0, tocolor(255, 255, 255, 20))
        end
		if (isMouseInPosition(631, 265, 16, 16) and not manageEdits) or aba == 5 then
            dxDrawImage(631, 265, 16, 16, "files/imgs/foods.png", 0, 0, 0, tocolor(173, 146, 255))
        else
            dxDrawImage(631, 265, 16, 16, "files/imgs/foods.png", 0, 0, 0, tocolor(255, 255, 255, 20))
        end
        dxDrawText("Inventário", 217, 259, 201, 13, tocolor(255, 255, 255, 90), 1.00, font, "left", "center", false, false, false, false, false)
        dxDrawText(puxarNome(localPlayer).." #"..puxarID(localPlayer), 217, 272, 201, 13, tocolor(255, 255, 255, 35), 1.00, font2, "left", "center", false, false, false, false, false)
        dxDrawText("#A0A0A0Peso atual: #646464"..pesoAtual.."kg", 206, 496, 269, 13, tocolor(255, 255, 255, 255), 1.00, font2, "left", "center", false, false, false, true, false)
        dxDrawText("#A0A0A0Peso máximo: #646464"..pesoMax.."kg", 452, 496, 189, 13, tocolor(255, 255, 255, 255), 1.00, font2, "right", "center", false, false, false, true, false)
        dxDrawImageSection(206, 514, (435/pesoMax*pesoAtual), 3, 0, 0, (435/pesoMax*pesoAtual), 3, "files/imgs/bar.png")

        dxDrawText("Porta-malas", 736, 259, 201, 13, tocolor(255, 255, 255, 90), 1.00, font, "left", "center", false, false, false, false, false)
        dxDrawText("Veículo: "..getVehicleNameFromModel(getElementModel(elementTrunk)), 736, 272, 201, 13, tocolor(255, 255, 255, 35), 1.00, font2, "left", "center", false, false, false, false, false)
        dxDrawText("#A0A0A0Peso atual: #646464"..pesoTargetAtual.."kg", 725, 496, 269, 13, tocolor(255, 255, 255, 255), 1.00, font2, "left", "center", false, false, false, true, false)
        dxDrawText("#A0A0A0Peso máximo: #646464"..pesoTargetMax.."kg", 971, 496, 189, 13, tocolor(255, 255, 255, 255), 1.00, font2, "right", "center", false, false, false, true, false)
        dxDrawImageSection(725, 514, (435/pesoTargetMax*pesoTargetAtual), 3, 0, 0, (435/pesoTargetMax*pesoTargetAtual), 3, "files/imgs/bar.png")
        for i, v in ipairs(myInv) do
            if aba == v[4] then
                if isMouseInPosition(Slots[v[5]][1], Slots[v[5]][2], 57, 57) or itemSelect == i then
                    dxDrawImage(Slots[v[5]][1]+11, Slots[v[5]][2]+14, 34, 34, ":TB_inventario/files/imgs/itens/"..v[1]..".png", 0, 0, 0, tocolor(255, 255, 255, 100), false)
                    if not manageEdits then
                        if isCursorShowing() then
                            local cx, cy = getCursorPosition()
                            local mx, my = cx * screen[1], cy * screen[2]
                            _dxDrawImage(mx, my, 127, 54, "files/imgs/info_cage.png")
                            _dxDrawText("#A0A0A0Nome: #AD92FF"..v[2], mx+5, my+6, ((mx+5)+119), ((my+6)+13), tocolor(255, 255, 255, 255), 1.00, font2, "left", "center", false, false, false, true, false)
                            _dxDrawText("#A0A0A0QTD: #AD92FFx"..v[3], mx+5, my+19, ((mx+5)+119), ((my+19)+13), tocolor(255, 255, 255, 255), 1.00, font2, "left", "center", false, false, false, true, false)
                            _dxDrawText("#A0A0A0Peso: #AD92FF"..v[7].."kg", mx+5, my+34, ((mx+5)+119), ((my+34)+13), tocolor(255, 255, 255, 255), 1.00, font2, "left", "center", false, false, false, true, false)
                        end
                    end
                else
                    dxDrawImage(Slots[v[5]][1]+11, Slots[v[5]][2]+14, 34, 34, ":TB_inventario/files/imgs/itens/"..v[1]..".png", 0, 0, 0, tocolor(255, 255, 255, 20), false)
                end
            end
        end
        for i, v in ipairs(targetInv) do
            if SlotsTarget[v[5]] then
                if isMouseInPosition(SlotsTarget[v[5]][1], SlotsTarget[v[5]][2], 57, 57) or itemTargetSelect == i then
                    dxDrawImage(SlotsTarget[v[5]][1]+11, SlotsTarget[v[5]][2]+14, 34, 34, ":TB_inventario/files/imgs/itens/"..v[1]..".png", 0, 0, 0, tocolor(255, 255, 255, 100), false)
                    if not manageEdits then
                        if isCursorShowing() then
                            local cx, cy = getCursorPosition()
                            local mx, my = cx * screen[1], cy * screen[2]
                            _dxDrawImage(mx, my, 127, 54, "files/imgs/info_cage.png")
                            _dxDrawText("#A0A0A0Nome: #AD92FF"..v[2], mx+5, my+6, ((mx+5)+119), ((my+6)+13), tocolor(255, 255, 255, 255), 1.00, font2, "left", "center", false, false, false, true, false)
                            _dxDrawText("#A0A0A0QTD: #AD92FFx"..v[3], mx+5, my+19, ((mx+5)+119), ((my+19)+13), tocolor(255, 255, 255, 255), 1.00, font2, "left", "center", false, false, false, true, false)
                            _dxDrawText("#A0A0A0Peso: #AD92FF"..v[7].."kg", mx+5, my+34, ((mx+5)+119), ((my+34)+13), tocolor(255, 255, 255, 255), 1.00, font2, "left", "center", false, false, false, true, false)
                        end
                    end
                else
                    dxDrawImage(SlotsTarget[v[5]][1]+11, SlotsTarget[v[5]][2]+14, 34, 34, ":TB_inventario/files/imgs/itens/"..v[1]..".png", 0, 0, 0, tocolor(255, 255, 255, 20), false)
                end
            end
        end
        if manageEdits then
            positionsAmount = 0
            if manageEdits == "targetInv" then
                positionsAmount = positionsAmount + 519
            end
            dxDrawImage(354+positionsAmount, 325, 140, 75, "files/imgs/manageedits.png")
            dxDrawImage(357+positionsAmount, 329, 134, 31, "files/imgs/button.png", 0, 0, 0, tocolor(255, 255, 255, 1))
            if isMouseInPosition(357+positionsAmount, 329, 134, 31) then
                dxDrawText(positionsAmount == 519 and "Retirar" or "Enviar", 357+positionsAmount, 329, 134, 31, tocolor(255, 255, 255, 70), 1.00, font2, "center", "center", false, false, false, false, false)
            else
                dxDrawText(positionsAmount == 519 and "Retirar" or "Enviar", 357+positionsAmount, 329, 134, 31, tocolor(255, 255, 255, 35), 1.00, font2, "center", "center", false, false, false, false, false)
            end
            createEditBox(357+positionsAmount, 365, 134, 31, tocolor(255, 255, 255, 35), font2, 1)
        end
    end
end

addEvent("JOAO.openTrunk", true)
addEventHandler("JOAO.openTrunk", root,
function(myInv_, targetInv_, elementTrunk_, weightTrunk_, weightMaxTrunk_, passwordTrunk_)
    if not isEventHandlerAdded("onClientRender", root, dx) then
        myInv = {}
        manageEdits = false
        select = false
        pesoTargetAtual = weightTrunk_
        pesoTargetMax = weightMaxTrunk_
        passwordTrunk = passwordTrunk_
        EditBox("add")
        for i, v in ipairs(myInv_) do
            myInv[i] = {v.itemID, v.nameItem, v.qnt, v.category, tonumber(v.slot), v.dataItem, exports["TB_inventario"]:getPesoItem(v.itemID, v.qnt)}
        end
        aba = 1
        itemTargetSelect = false
        itemSelect = false
        targetInv = {}
        for i, v in ipairs(targetInv_) do
            targetInv[i] = {v.itemID, v.nameItem, v.quantity, _, tonumber(v.slot), v.dataItem, exports["TB_inventario"]:getPesoItem(v.itemID, v.quantity)}
        end
        elementTrunk = elementTrunk_
        window = "index"
        addEventHandler("onClientRender", root, dx)
        showCursor(true)
    end
end)

addEventHandler("onClientClick", root,
function(button, state)
    if button == "left" and state == "up" then
        if isEventHandlerAdded("onClientRender", root, dx) then
            select = false
            if guiGetText(edits[1]) == "" then guiSetText(edits[1], "Quantidade") end
            if window == "index" then
                for i, v in ipairs(myInv) do
                    if aba == v[4] then
                        if (selectSlot ~= v[5]) then
                            if isMouseInPosition(Slots[v[5]][1], Slots[v[5]][2], 57, 57) then
                                manageEdits = "myInv"
                                itemSelect = i
                                playSound("files/sounds/release.mp3")
                                return
                            end
                        end
                    end
                end
                for i, v in ipairs(targetInv) do
                    if SlotsTarget[v[5]] then
                        if isMouseInPosition(SlotsTarget[v[5]][1], SlotsTarget[v[5]][2], 57, 57) then
                            manageEdits = "targetInv"
                            itemTargetSelect = i
                            playSound("files/sounds/release.mp3")
                            return
                        end
                    end
                end
                if (isMouseInPosition(535, 265, 10, 14) and not manageEdits) then
                    aba = 1
                    return
                end
                if (isMouseInPosition(559, 266, 11, 12) and not manageEdits) then
                    aba = 2
                    return
                end
                if (isMouseInPosition(583, 266, 16, 12) and not manageEdits) then
                    aba = 3
                    return
                end
				if (isMouseInPosition(607, 257, 18, 24) and not manageEdits) then
                    aba = 4
                    return
                end
				if (isMouseInPosition(631, 265, 16, 16) and not manageEdits) then
                    aba = 5
                    return
                end
                if manageEdits then
                    if isMouseInPosition(357+positionsAmount, 329, 134, 31) then
                        if guiGetText(edits[1]) == "" or guiGetText(edits[1]) == "Quantidade" then
                            notifyC("Digite a quantidade!", "error")
                            return
                        end
                        local quantity = tonumber(guiGetText(edits[1]))
                        if not quantity then
                            notifyC("A quantidade precisa ser em número!", "error")
                            return
                        end
                        if verifyNumber(quantity) then
                            notifyC("Algo de errado com a quantidade!", "error")
                            return
                        end
                        if positionsAmount == 519 then
                            triggerServerEvent("JOAO.withdrawTrunk", localPlayer, localPlayer, targetInv[itemTargetSelect][2], quantity, elementTrunk, targetInv[itemTargetSelect][1])
                        else
                            triggerServerEvent("JOAO.sendTrunk", localPlayer, localPlayer, myInv[itemSelect][2], quantity, elementTrunk, myInv[itemSelect][1])
                        end
                        select = false
                        guiSetText(edits[1], "Quantidade")
                        itemTargetSelect = false
                        itemSelect = false
                        manageEdits = false
                        return
                    end
                    if isMouseInPosition(357+positionsAmount, 365, 134, 31) then
                        select = false
                        if guiEditSetCaretIndex(edits[1], string.len(guiGetText(edits[1]))) then
                            select = 1
                            guiBringToFront(edits[1])
                            guiSetInputMode("no_binds_when_editing") 
                            if (guiGetText(edits[1]) == "Quantidade") then 
                                guiSetText(edits[1], "")
                            end
                        end
                        return
                    end
                end
                if not manageEdits then
                    itemSelect = false
                    itemTargetSelect = false
                end
            end
        end
    end
end)

addEvent("JOAO.updateTrunk", true)
addEventHandler("JOAO.updateTrunk", root,
function(myInv_, targetInv_)
    myInv = {}
    targetInv = {}
    itemTargetSelect = false
    itemSelect = false
    manageEdits = false
    for i, v in ipairs(myInv_) do
        myInv[i] = {v.itemID, v.nameItem, v.qnt, v.category, tonumber(v.slot), v.dataItem, exports["TB_inventario"]:getPesoItem(v.itemID, v.qnt)}
    end
    for i, v in ipairs(targetInv_) do
        targetInv[i] = {v.itemID, v.nameItem, v.quantity, _, tonumber(v.slot), v.dataItem, exports["TB_inventario"]:getPesoItem(v.itemID, v.quantity)}
    end
end)

function closeMenu()
    if isEventHandlerAdded("onClientRender", root, dx) then
        setElementData(elementTrunk, "JOAO.occupiedBau", false)
        elementTrunk = false
        EditBox('destroy')
        removeEventHandler("onClientRender", root, dx)
        showCursor(false)
        setElementData(localPlayer, 'JOAO.bauAberto', false)
    end
end
bindKey("backspace", "down", closeMenu)

function EditBox(tipo)
    if tipo == 'destroy' then
        for i=1, #edits do
            if isElement(edits[i]) then 
                destroyElement(edits[i])
            end
        end
    elseif tipo == 'add' then
        edits[1] = guiCreateEdit(-1000, -1000, 325, 50, 'Quantidade', false)
        guiEditSetMaxLength(edits[1], 1000)
        guiSetProperty(edits[1], 'ValidationString', '[0-9]*')
	end 
end

function isEventHandlerAdded( sEventName, pElementAttachedTo, func )
    if type( sEventName ) == "string" and isElement( pElementAttachedTo ) and type( func ) == "function" then
        local aAttachedFunctions = getEventHandlers( sEventName, pElementAttachedTo )
        if type( aAttachedFunctions ) == "table" and #aAttachedFunctions > 0 then
            for i, v in ipairs( aAttachedFunctions ) do
                if v == func then
                    return true
                end
            end
        end
    end
    return false
end