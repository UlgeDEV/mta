--##################################
--## Script feito por zJoaoFtw_   ##
--##################################

config = {
    ["Mensagem Start"] = true, --Caso esteja false ele não irá aparecer a mensagem!
}