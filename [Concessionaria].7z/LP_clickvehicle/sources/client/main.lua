local screen = {guiGetScreenSize()}
local sx, sy = (screen[1]/1366), (screen[2]/768)

function isMouseInPosition(x,y,w,h)
    if isCursorShowing() then
        local sx,sy = guiGetScreenSize()
        local cx,cy = getCursorPosition()
        local cx,cy = (cx*sx),(cy*sy)
        if (cx >= x and cx <= x+w) and (cy >= y and cy <= y+h) then
            return true
        end
    end
end

_dxDrawImageSem = dxDrawImage
function dxDrawImageSem (x, y, w, h, ...)
    return _dxDrawImageSem (x, y, w, h, ...)
end

_dxDrawImageSectionSem = dxDrawImageSection
function dxDrawImageSectionSem (x, y, w, h, ...)
    return _dxDrawImageSectionSem (x, y, w, h, ...)
end

_isMouseInPositionSem = isMouseInPosition
function isMouseInPositionSem (x, y, w, h)
    return _isMouseInPositionSem (x, y, w, h)
end

_dxCreateFontSem = dxCreateFont
function dxCreateFontSem (file, tamanho)
    return _dxCreateFontSem (file, tamanho)
end

_dxDrawRectangleSem = dxDrawRectangle
function dxDrawRectangleSem (x, y, w, h, ...)
    return _dxDrawRectangleSem (x, y, w, h, ...)
end

_dxDrawTextSem = dxDrawText
function dxDrawTextSem (text, x, y, w, h, ...)
    return _dxDrawTextSem (text, x, y, w, h, ...)
end

_dxDrawImage = dxDrawImage
function dxDrawImage (x, y, w, h, ...)
    local x, y, w, h = sx * x, sy * y, sx * w, sy * h
    return _dxDrawImage (x, y, w, h, ...)
end

_dxDrawImageSection = dxDrawImageSection
function dxDrawImageSection (x, y, w, h, ...)
    local x, y, w, h = sx * x, sy * y, sx * w, sy * h
    return _dxDrawImageSection (x, y, w, h, ...)
end

_isMouseInPosition = isMouseInPosition
function isMouseInPosition (x, y, w, h)
    local x, y, w, h = sx * x, sy * y, sx * w, sy * h
    return _isMouseInPosition (x, y, w, h)
end

_dxCreateFont = dxCreateFont
function dxCreateFont (file, tamanho)
    local tamanho = sx * tamanho
    return _dxCreateFont (file, tamanho)
end

_dxDrawRectangle = dxDrawRectangle
function dxDrawRectangle (x, y, w, h, ...)
    local x, y, w, h = sx * x, sy * y, sx * w, sy * h
    return _dxDrawRectangle (x, y, w, h, ...)
end

_dxDrawText = dxDrawText
function dxDrawText (text, x, y, w, h, ...)
    local x, y, w, h = sx * x, sy * y, sx * w, sy * h
    return _dxDrawText (text, x, y, w, h, ...)
end

local font = dxCreateFontSem("files/fonts/Roboto-Regular.ttf", 10)
local font2 = dxCreateFontSem("files/fonts/Roboto-Regular.ttf", 10)

function dx()
    if isElement(vehicle) then
        local pos = {getElementPosition(localPlayer)}
        local posVeh = {getElementPosition(vehicle)}
        local distance = getDistanceBetweenPoints3D(pos[1], pos[2], pos[3], posVeh[1], posVeh[2], posVeh[3])
        if distance <= 3 then
            dxDrawImageSem(absX, absY, 160, 120, "files/imgs/base.png")
            dxDrawTextSem(getVehicleNameFromModel(getElementModel(vehicle)), absX+80, absY+15, absX+80, absY+15, tocolor(155, 111, 199, 255), 1.00, font, "center", "center", false, false, false, false, false)
            if isMouseInPositionSem(absX, absY+30, 150, 30) then
                dxDrawImageSem(absX, absY+30, 30, 30, "files/imgs/chaved.png", 0, 0, 0, tocolor(241, 241, 241, 170))
                dxDrawTextSem(isVehicleLocked(vehicle) and "Destrancar veículo" or "Trancar veículo", absX+30, absY+45, absX+30, absY+45, tocolor(255, 255, 255, 255), 1.00, font2, "left", "center", false, false, false, false, false)
            else
                dxDrawImageSem(absX, absY+30, 30, 30, "files/imgs/chaved.png", 0, 0, 0, tocolor(241, 241, 241, 63))
                dxDrawTextSem(isVehicleLocked(vehicle) and "Destrancar veículo" or "Trancar veículo", absX+30, absY+45, absX+30, absY+45, tocolor(255, 255, 255, 178), 1.00, font2, "left", "center", false, false, false, false, false)
            end
            if isMouseInPositionSem(absX, absY+60, 150, 30) then
                dxDrawImageSem(absX, absY+60, 30, 30, "files/imgs/vehicle.png", 0, 0, 0, tocolor(241, 241, 241, 170))
                dxDrawTextSem("Abrir porta-malas", absX+30, absY+75, absX+30, absY+75, tocolor(255, 255, 255, 255), 1.00, font2, "left", "center", false, false, false, false, false)
            else
                dxDrawImageSem(absX, absY+60, 30, 30, "files/imgs/vehicle.png", 0, 0, 0, tocolor(241, 241, 241, 63))
                dxDrawTextSem("Abrir porta-malas", absX+30, absY+75, absX+30, absY+75, tocolor(255, 255, 255, 178), 1.00, font2, "left", "center", false, false, false, false, false)
            end
            if isMouseInPositionSem(absX, absY+90, 150, 30) then
                dxDrawImageSem(absX, absY+90, 30, 30, "files/imgs/close.png", 0, 0, 0, tocolor(241, 241, 241, 170))
                dxDrawTextSem("Cancelar", absX+30, absY+105, absX+30, absY+105, tocolor(255, 255, 255, 255), 1.00, font2, "left", "center", false, false, false, false, false)
            else
                dxDrawImageSem(absX, absY+90, 30, 30, "files/imgs/close.png", 0, 0, 0, tocolor(241, 241, 241, 63))
                dxDrawTextSem("Cancelar", absX+30, absY+105, absX+30, absY+105, tocolor(255, 255, 255, 178), 1.00, font2, "left", "center", false, false, false, false, false)
            end
        else
            closeMenu()
        end
    else
        closeMenu()
    end
end

addEvent("JOAO.openClickVehicle", true)
addEventHandler("JOAO.openClickVehicle", root,
function(vehicle_)
    if not isEventHandlerAdded("onClientRender", root, dx) then
        vehicle = vehicle_
        cursorX,cursorY = getCursorPosition()
        absX,absY = cursorX*screen[1],cursorY*screen[2]
        addEventHandler("onClientRender", root, dx)
        showCursor(true)
    end
end)

addEventHandler("onClientClick", root,
function(button, state)
    if button == "left" and state == "up" then
        if isEventHandlerAdded("onClientRender", root, dx) then
            if isMouseInPositionSem(absX, absY+30, 150, 30) then
                triggerServerEvent("JOAO.manageClickVehicle", localPlayer, localPlayer, vehicle, "trancar")
            end
            if isMouseInPositionSem(absX, absY+60, 150, 30) then
                triggerServerEvent("JOAO.manageClickVehicle", localPlayer, localPlayer, vehicle, "portasmalas")
            end
            if isMouseInPositionSem(absX, absY+90, 150, 30) then
                closeMenu()
            end
        end
    end
end)

function closeMenu()
    if isEventHandlerAdded("onClientRender", root, dx) then
        removeEventHandler("onClientRender", root, dx)
        showCursor(false)
    end
end
addEvent("JOAO.closeClickVehicle", true)
addEventHandler("JOAO.closeClickVehicle", root, closeMenu)

function isEventHandlerAdded( sEventName, pElementAttachedTo, func )
    if type( sEventName ) == "string" and isElement( pElementAttachedTo ) and type( func ) == "function" then
        local aAttachedFunctions = getEventHandlers( sEventName, pElementAttachedTo )
        if type( aAttachedFunctions ) == "table" and #aAttachedFunctions > 0 then
            for i, v in ipairs( aAttachedFunctions ) do
                if v == func then
                    return true
                end
            end
        end
    end
    return false
end