addEventHandler("onResourceStart", resourceRoot,
function()
    if config["Mensagem Start"] then
        outputDebugString("["..getResourceName(getThisResource()).."] Startado com sucesso, qualquer bug contacte zJoaoFtw_#5562!")
    end
    addEventHandler("onElementClicked", root,
    function(button, state, player)
        if button == "right" and state == "up" then
            if isElement(player) then
                if isElement(source) then
                    if getElementType(source) == "vehicle" then
                        local pos = {getElementPosition(player)}
                        local posVeh = {getElementPosition(source)}
                        local distance = getDistanceBetweenPoints3D(pos[1], pos[2], pos[3], posVeh[1], posVeh[2], posVeh[3])
                        if distance <= 3 then
                            if not getPedOccupiedVehicle(player) then
                                triggerClientEvent(player, "JOAO.openClickVehicle", player, source)
                            end
                        end
                    end
                end
            end
        end
    end)
end)

addEvent("JOAO.manageClickVehicle", true)
addEventHandler("JOAO.manageClickVehicle", root,
function(player, vehicle, type_)
    if type_ == "trancar" then
        local identity = getElementData(vehicle, 'JOAO.identityCar')
        local data = exports["TB_inventario"]:getItemDataByData(player, identity)
        if data then 
            if (isVehicleLocked(vehicle)) then 
                setVehicleLocked(vehicle, false)
                setElementData(vehicle, "veh:lock", false)
				setTimer(lightsEfffect, 150, 4, vehicle)
                triggerClientEvent(player, "JOAO.playSoundMANAGE", player, ":TB_managecar/files/sounds/locked.mp3")
                notifyS(player, "Veiculo destrancado!", "info")
            else 
                setVehicleLocked(vehicle, true)
                setElementData(vehicle, "veh:lock", true)
				setTimer(lightsEfffect, 150, 4, vehicle)
                triggerClientEvent(player, "JOAO.playSoundMANAGE", player, ":TB_managecar/files/sounds/unlocked.mp3")
                notifyS(player, "Veiculo trancado!", "info")
            end
        else
            notifyS(player, "Você não está com as chave do veículo!", "error")
        end
    elseif type_ == "portasmalas" then
        triggerEvent("JOAO.openTrunk", player, player, vehicle)
        triggerClientEvent('JOAO.closeClickVehicle', player, player)
    end
end)
function lightsEfffect(veh)
	if veh and isElement(veh) and getElementType(veh) == "vehicle" then 
		lights = getVehicleOverrideLights(veh)
		if (lights == 2) then
			setVehicleOverrideLights(veh, 1)
		else
			setVehicleOverrideLights(veh, 2)
		end
	end 
end