local font = dxCreateFont("files/fonts/medium.ttf", 10)

function dx()
    if not getPedOccupiedVehicle(localPlayer) then closeMenu() return end
    if window == "manage" then
        -- dxDrawImage(0, 0, 1366, 768, "files/imgs/base.png")
        dxDrawRectangle(585, 694, 201, 57, tocolor(29, 29, 29, 200), false)

        if isMouseInPosition(593, 694, 37, 56) then
            dxDrawImage(600, 716, 22, 17, "files/imgs/engine.png", 0, 0, 0, tocolor(173, 146, 255))
            dxDrawImage(593, 694, 37, 56, "files/imgs/select.png")
        else
            dxDrawImage(600, 716, 22, 17, "files/imgs/engine.png", 0, 0, 0, tocolor(255, 255, 255, 255))
        end
        if isMouseInPosition(635, 694, 37, 56) then
            dxDrawImage(644, 717, 19, 14, "files/imgs/light.png", 0, 0, 0, tocolor(173, 146, 255))
            dxDrawImage(635, 694, 37, 56, "files/imgs/select.png")
        else
            dxDrawImage(644, 717, 19, 14, "files/imgs/light.png", 0, 0, 0, tocolor(255, 255, 255, 255))
        end
        if isMouseInPosition(668, 694, 37, 56) then
            dxDrawImage(679, 715, 15, 19, "files/imgs/handbrake.png", 0, 0, 0, tocolor(173, 146, 255))
            dxDrawImage(668, 694, 37, 56, "files/imgs/select.png")
        else
            dxDrawImage(679, 715, 15, 19, "files/imgs/handbrake.png", 0, 0, 0, tocolor(255, 255, 255, 255))
        end
        if isMouseInPosition(701, 694, 37, 56) then
            dxDrawImage(711, 714, 17, 20, "files/imgs/locked.png", 0, 0, 0, tocolor(173, 146, 255))
            dxDrawImage(701, 694, 37, 56, "files/imgs/select.png")
        else
            dxDrawImage(711, 714, 17, 20, "files/imgs/locked.png", 0, 0, 0, tocolor(255, 255, 255, 255))
        end
        if isMouseInPosition(739, 694, 37, 56) then
            dxDrawImage(748, 715, 18, 18, "files/imgs/doors.png", 0, 0, 0, tocolor(173, 146, 255))
            dxDrawImage(739, 694, 37, 56, "files/imgs/select.png")
        else
            dxDrawImage(748, 715, 18, 18, "files/imgs/doors.png", 0, 0, 0, tocolor(255, 255, 255, 255))
        end
    elseif window == "doors" then
        dxDrawImage(534, 264, 298, 482, "files/imgs/base_doors.png")
        if isMouseInPosition(666, 719, 11, 6) then
            dxDrawImage(666, 719, 11, 6, "files/imgs/up.png", 0, 0, 0, tocolor(173, 146, 255))
        else
            dxDrawImage(666, 719, 11, 6, "files/imgs/up.png", 0, 0, 0, tocolor(255, 255, 255, 15))
        end
        if isMouseInPosition(692, 719, 11, 6) then
            dxDrawImage(692, 719, 11, 6, "files/imgs/down.png", 0, 0, 0, tocolor(173, 146, 255))
        else
            dxDrawImage(692, 719, 11, 6, "files/imgs/down.png", 0, 0, 0, tocolor(255, 255, 255, 15))
        end
        dxDrawImage(588, 628, 190, 49, "files/imgs/trunk.png")
        dxDrawImage(588, 293, 190, 49, "files/imgs/front.png")
        if isMouseInPosition(588, 293, 190, 40) then
            dxDrawText("Abrir capô do veículo", 588, 293, 190, 40, tocolor(255, 255, 255, 60), 1.00, font, "center", "center", false, false, false, false, false)
        else
            dxDrawText("Abrir capô do veículo", 588, 293, 190, 40, tocolor(255, 255, 255, 15), 1.00, font, "center", "center", false, false, false, false, false)
        end
        if isMouseInPosition(588, 637, 190, 40) then
            dxDrawText("Abrir porta-malas do veículo", 588, 637, 190, 40, tocolor(255, 255, 255, 60), 1.00, font, "center", "center", false, false, false, false, false)
        else
            dxDrawText("Abrir porta-malas do veículo", 588, 637, 190, 40, tocolor(255, 255, 255, 15), 1.00, font, "center", "center", false, false, false, false, false)
        end
        if isMouseInPosition(592, 442, 40, 37) then
            dxDrawImage(592, 442, 40, 37, "files/imgs/bar_door_left.png", 0, 0, 0, tocolor(173, 146, 255))
        end
        if isMouseInPosition(592, 502, 40, 37) then
            dxDrawImage(592, 502, 40, 37, "files/imgs/bar_door_left.png", 0, 0, 0, tocolor(173, 146, 255))
        end
        if isMouseInPosition(733, 438, 41, 44) then
            dxDrawImage(733, 438, 41, 44, "files/imgs/bar_door_right.png", 0, 0, 0, tocolor(173, 146, 255))
        end
        if isMouseInPosition(733, 498, 41, 44) then
            dxDrawImage(733, 498, 41, 44, "files/imgs/bar_door_right.png", 0, 0, 0, tocolor(173, 146, 255))
        end
        dxDrawImage(476, 278, 413, 413, "files/imgs/car.png")
    end
end

bindKey("l", "down",
function()
    local veh = getPedOccupiedVehicle(localPlayer)
    if not veh then return end
    if isMTAWindowActive ( ) then return end
    if not isEventHandlerAdded("onClientRender", root, dx) then
        window = "manage"
        addEventHandler("onClientRender", root, dx)
        showCursor(true)
        showChat(false)
    else
        closeMenu()
    end
end)

addEventHandler("onClientClick", root,
function(_, state)
    if state == "up" then
        if isEventHandlerAdded("onClientRender", root, dx) then
            if window == "manage" then
                if isMouseInPosition(593, 694, 37, 56) then
                    triggerServerEvent("JOAO.manageCarMANAGE", localPlayer, localPlayer, "motor")
                end
                if isMouseInPosition(635, 694, 37, 56) then
                    triggerServerEvent("JOAO.manageCarMANAGE", localPlayer, localPlayer, "farol")
                end
                if isMouseInPosition(668, 694, 37, 56) then
                    triggerServerEvent("JOAO.manageCarMANAGE", localPlayer, localPlayer, "freio")
                end
                if isMouseInPosition(701, 694, 37, 56) then
                    triggerServerEvent("JOAO.manageCarMANAGE", localPlayer, localPlayer, "trancar")
                end
                if isMouseInPosition(739, 694, 37, 56) then
                    window = "doors"
                end
            elseif window == "doors" then
                if isMouseInPosition(666, 719, 11, 6) then
                    triggerServerEvent("JOAO.suspensionManage", localPlayer, localPlayer, "up")
                end
                if isMouseInPosition(692, 719, 11, 6) then
                    triggerServerEvent("JOAO.suspensionManage", localPlayer, localPlayer, "down")
                end
                if isMouseInPosition(588, 293, 190, 40) then
                    triggerServerEvent("JOAO.manageVehicleDoors", localPlayer, localPlayer, "hood")
                end
                if isMouseInPosition(588, 637, 190, 40) then
                    triggerServerEvent("JOAO.manageVehicleDoors", localPlayer, localPlayer, "trunk")
                end
                if isMouseInPosition(592, 442, 40, 37) then
                    triggerServerEvent("JOAO.manageVehicleDoors", localPlayer, localPlayer, "left_door_primary")
                end
                if isMouseInPosition(592, 502, 40, 37) then
                    triggerServerEvent("JOAO.manageVehicleDoors", localPlayer, localPlayer, "left_door_secondary")
                end
                if isMouseInPosition(733, 438, 41, 44) then
                    triggerServerEvent("JOAO.manageVehicleDoors", localPlayer, localPlayer, "right_door_primary")
                end
                if isMouseInPosition(733, 498, 41, 44) then
                    triggerServerEvent("JOAO.manageVehicleDoors", localPlayer, localPlayer, "right_door_secondary")
                end
            end
        end
    end
end)

bindKey("backspace", "down",
    function()
        if window == "doors" then
            window = "manage"
        else
            if isEventHandlerAdded("onClientRender", root, dx) then
                removeEventHandler("onClientRender", root, dx)
                showCursor(false)
                showChat(true)
            end
        end
    end
);

function closeMenu()
    if isEventHandlerAdded("onClientRender", root, dx) then
        removeEventHandler("onClientRender", root, dx)
        showCursor(false)
        showChat(true)
    end
end

addEvent('JOAO.playSoundMANAGE', true)
addEventHandler('JOAO.playSoundMANAGE', root, 
function(file)
    playSound(file)  
end)

function isEventHandlerAdded( sEventName, pElementAttachedTo, func )
    if type( sEventName ) == "string" and isElement( pElementAttachedTo ) and type( func ) == "function" then
        local aAttachedFunctions = getEventHandlers( sEventName, pElementAttachedTo )
        if type( aAttachedFunctions ) == "table" and #aAttachedFunctions > 0 then
            for i, v in ipairs( aAttachedFunctions ) do
                if v == func then
                    return true
                end
            end
        end
    end
    return false
end