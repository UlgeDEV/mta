tableTrunkInventory = {}

addEventHandler("onResourceStart", resourceRoot,
function()
    db = dbConnect("sqlite", "data.sqlite")
    dbExec(db, "CREATE TABLE IF NOT EXISTS TrunkInventory(id, itemID, nameItem, quantity, slot, dataItem)")
    dbQuery(saveQuery, db, "SELECT * FROM TrunkInventory")
    for i, v in ipairs(getElementsByType("vehicle")) do
        setElementData(v, "JOAO.occupiedBau", false)
    end
    if config["Mensagem Start"] then
        outputDebugString("["..getResourceName(getThisResource()).."] Startado com sucesso, qualquer bug contacte zJoaoFtw_#5562!")
    end
end)

addEvent("JOAO.openTrunk", true)
addEventHandler("JOAO.openTrunk", root,
function(player, vehicle)
    if player and vehicle then
        if (vehicle and getElementType(vehicle) == "vehicle" and (getElementData(vehicle, "JOAO.identityCar") or false)) then
            if isVehicleLocked(vehicle) then
                notifyS(player, "Este veícuo está trancado!", "info")
            else
                if not (getElementData(vehicle, "JOAO.occupiedBau") or false) or not isElement((getElementData(vehicle, "JOAO.occupiedBau") or false)) and (getElementData(vehicle, "JOAO.identityCar") or false) then
                    if --[[not getPedOccupiedVehicle(player) and]] not isVehicleLocked(vehicle) then
                        if getElementData(player, 'Desmaiado') then
                            notifyS(player, "Você está desmaiado!", "error")
                        else
                            if getDistanceBetweenPoints3D(Vector3(getElementPosition(vehicle)), Vector3(getElementPosition(player))) <= 5 then
                                if not tableTrunkInventory[(getElementData(vehicle, "JOAO.identityCar") or 0)] then tableTrunkInventory[(getElementData(vehicle, "JOAO.identityCar") or 0)] = {} end
                                setElementData(vehicle, "JOAO.occupiedBau", player)
                                local invplayer = exports["LP_inventario"]:getTablePlayer(puxarConta(player))
                                local invbau = tableTrunkInventory[(getElementData(vehicle, "JOAO.identityCar") or 0)]
                                local pesobau = exports["LP_inventario"]:getWeightBau(invbau)
                                triggerClientEvent(player, "JOAO.openTrunk", player, invplayer, invbau, vehicle, pesobau, (getElementData(vehicle, "JOAO.sizePortaMalas") or 150))
                            else 
                                notifyS(player, "Este veículo está muito distante de você!", "error")
                            end 
                        end
                    else 
                        if (getElementData(vehicle, "JOAO.occupiedBau") or false) ~= player then 
                            notifyS(player, "Este veículo está ocupado, aguarde!", "error")
                        end 
                    end
                end
            end
        end
    end
end)

addEvent("JOAO.sendTrunk", true)
addEventHandler("JOAO.sendTrunk", root,
function(player, nameItem, quantity, target, idItem)
    if nameItem and quantity and target and idItem then
        if quantity <= 0 then
            notifyS(player, "A quantidade deve ser maior que zero!", "error")
            return
        end
        local tableItemCalc = getTrunkRow((getElementData(target, "JOAO.identityCar") or 0), nameItem)
        local verifyItemSpecial = exports["LP_inventario"]:getItemSpecial(idItem)
        local verifyItemBlacklist = exports["LP_inventario"]:getItemBlacklist(idItem)
        if (verifyItemBlacklist) then
            notifyS(player, 'Esse item é bloqueado de enviar', 'error')
            return
        end
        if verifyItemSpecial then
            local quantidadeplayer = exports["TB_inventario"]:getItemByName(player, nameItem)
            local pesobau = exports["LP_inventario"]:getWeightBau(tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)])
            if tonumber(quantidadeplayer) < tonumber(quantity) then 
                notifyS(player, "Você não tem esta quantidade!", "error")
            else
                local pesoItem = exports["LP_inventario"]:getPesoItem(idItem, quantity)
                if (pesobau+pesoItem) > tonumber((getElementData(target, "JOAO.sizePortaMalas") or 150)) then
                    notifyS(player, "O baú está cheio!", "error")
                else
                    local identity = exports["LP_inventario"]:getIdentityByID(player, idItem)
                    if not identity then return end
                    local jsonData = exports["LP_inventario"]:getItemDataByData(player, identity)
                    exports["LP_inventario"]:takeItem(player, identity, quantity)
                    if not tableItemCalc then
                        local freeSlot = getFreeSlot((getElementData(target, "JOAO.identityCar") or 0), {})
                        dbExec(db, "INSERT INTO TrunkInventory (id, itemID, nameItem, quantity, slot, dataItem) VALUES(?,?,?,?,?,?)", (getElementData(target, "JOAO.identityCar") or 0), tonumber(idItem), nameItem, quantity, freeSlot, jsonData)
                        table.insert(tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)], {
                            id = (getElementData(target, "JOAO.identityCar") or 0),
                            itemID = tonumber(idItem),
                            nameItem = nameItem,
                            quantity = quantity,
                            slot = freeSlot,
                            dataItem = jsonData,
                        })
                    end 
                    updateTrunk(player, target)
                    takeAllWeapons(player)
                end
            end 
        else
            local quantidadeplayer = exports["LP_inventario"]:getItem(player, idItem)
            local pesobau = exports["LP_inventario"]:getWeightBau(tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)])
            if tonumber(quantidadeplayer) < tonumber(quantity) then 
                notifyS(player, "Você não tem esta quantidade!", "error")
            else
                local pesoItem = exports["LP_inventario"]:getPesoItem(idItem, quantity)
                if (pesobau+pesoItem) > tonumber((getElementData(target, "JOAO.sizePortaMalas") or 150)) then
                    notifyS(player, "O baú está cheio!", "error")
                else
                    exports["LP_inventario"]:takeItem(player, idItem, quantity)
                    if tableItemCalc then 
                        dbExec(db, "UPDATE TrunkInventory SET quantity=? WHERE id=? AND itemID=?", tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)][tableItemCalc].quantity+quantity, (getElementData(target, "JOAO.identityCar") or 0), tonumber(idItem))
                        tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)][tableItemCalc].quantity = tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)][tableItemCalc].quantity + quantity
                    else 
                        local freeSlot = getFreeSlot((getElementData(target, "JOAO.identityCar") or 0), {})
                        dbExec(db, "INSERT INTO TrunkInventory (id, itemID, nameItem, quantity, slot, dataItem) VALUES(?,?,?,?,?,?)", (getElementData(target, "JOAO.identityCar") or 0), tonumber(idItem), nameItem, quantity, freeSlot, nil)
                        table.insert(tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)], {
                            id = (getElementData(target, "JOAO.identityCar") or 0),
                            itemID = tonumber(idItem),
                            nameItem = nameItem,
                            quantity = quantity,
                            slot = freeSlot,
                            dataItem = nil,
                        })
                        --exports['[BVR]Util']:messageDiscord('O jogador '..puxarConta(player)..'('..puxarID(player)..') guardou o item '..nameItem..' ('..idItem..') com a quantia de '..quantity..'x ', 'https://discordapp.com/api/webhooks/1025918590463000688/jbuJnvd-g1-1sO6lUho-Fjydxqd0HsQh2NFnWLbhrCaVkQflH9dIPWg2RwfJWtrdhxRC')
                    end 
                    updateTrunk(player, target)
                    takeAllWeapons(player)
                end
            end 
        end
    end
end)

addEvent("JOAO.withdrawTrunk", true)
addEventHandler("JOAO.withdrawTrunk", root,
function(player, nameItem, quantity, target, idItem)
    if nameItem and quantity and target and idItem then
        if quantity <= 0 then
            notifyS(player, "A quantidade deve ser maior que zero!", "error")
            return
        end
        local tableItemCalc = getTrunkRow((getElementData(target, "JOAO.identityCar") or 0), nameItem)
        local verifyItemSpecial = exports["LP_inventario"]:getItemSpecial(idItem)
        local verifyItemBlacklist = exports["LP_inventario"]:getItemBlacklist(idItem)
        if (verifyItemBlacklist) then
            notifyS(player, 'Esse item é bloqueado de pegar', 'error')
            return
        end
        if verifyItemSpecial then
            if tonumber(tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)][tableItemCalc].quantity) >= tonumber(quantity) then 
                if exports["LP_inventario"]:giveItem(player, idItem, quantity, fromJSON(tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)][tableItemCalc].dataItem)) then 
                    dbExec(db, "DELETE FROM TrunkInventory WHERE id=? AND nameItem=?", (getElementData(target, "JOAO.identityCar") or 0), nameItem)
                    table.remove(tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)], tableItemCalc)
                end
            else
                notifyS(player, "O baú não tem essa quantia!", "error")
            end 
        else
            if tonumber(tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)][tableItemCalc].quantity) == tonumber(quantity) then 
                if exports["LP_inventario"]:giveItem(player, idItem, quantity) then 
                    dbExec(db, "DELETE FROM TrunkInventory WHERE id=? AND itemID=?", (getElementData(target, "JOAO.identityCar") or 0), idItem)
                    table.remove(tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)], tableItemCalc)
                end 
            elseif tonumber(tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)][tableItemCalc].quantity) > tonumber(quantity) then 
                if exports["LP_inventario"]:giveItem(player, idItem, quantity) then 
                    dbExec(db, "UPDATE TrunkInventory SET quantity=? WHERE id=? AND itemID=?", tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)][tableItemCalc].quantity-quantity, (getElementData(target, "JOAO.identityCar") or 0), idItem)
                    tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)][tableItemCalc].quantity = tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)][tableItemCalc].quantity - quantity
                end 
            else
                notifyS(player, "O baú não tem essa quantia!", "error")
            end 
            --exports['[BVR]Util']:messageDiscord('O jogador '..puxarConta(player)..'('..puxarID(player)..') pegou o item '..idItem..' com a quantia de '..quantity..'x ', 'https://discordapp.com/api/webhooks/1025918590463000688/jbuJnvd-g1-1sO6lUho-Fjydxqd0HsQh2NFnWLbhrCaVkQflH9dIPWg2RwfJWtrdhxRC')
        end
        updateTrunk(player, target)
    end
end)

function updateTrunk(player, target)
    local myInv = exports["LP_inventario"]:getTablePlayer(puxarConta(player))
    local invbau = tableTrunkInventory[(getElementData(target, "JOAO.identityCar") or 0)]
    local pesobau = exports["LP_inventario"]:getWeightBau(invbau)
    triggerClientEvent(player, "JOAO.updateTrunk", player, myInv, invbau, pesobau, target)
end

function getTrunkRow(idBau, nameItem)
    if tableTrunkInventory[idBau] then
        for i, v in ipairs(tableTrunkInventory[idBau]) do
            if v.nameItem == nameItem then
                return i
            end
        end
    end
    return false
end

function getFreeSlot(acc, tab)
    local result = dbPoll(dbQuery(db, "SELECT slot FROM TrunkInventory WHERE id = ? ORDER BY slot ASC", acc, tab), -1)
    newID = false
    for i, id in ipairs(result) do
        if id["slot"] ~= i then
            newID = i
            break
        end
    end
    if not (newID) then
        newID = #result + 1 
    end
    return newID
end

function saveQuery(queryTable)
    local result = dbPoll(queryTable, 0)
    for i=1, #result do
        local row = result[i]
        if not tableTrunkInventory[row.id] then tableTrunkInventory[row.id] = {} end
        table.insert(tableTrunkInventory[row.id], row)
    end
end