--##################################
--## Script feito por zJoaoFtw_   ##
--##################################

config = {
    ["Mensagem Start"] = false, --Caso esteja false ele não irá aparecer a mensagem!
    ["Weight Template"] = 30, --Peso padrão do porta-malas
}