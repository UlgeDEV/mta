markersCustom = {}
tableGarage = {}
stockDealerShip = {}
dimTest = 0
testDriveCar = {}
posSave = {}
rotSave = {}
timerDriver = {}
carTest = {}
vehicle = {}
blip_create = {}

addEventHandler("onResourceStart", resourceRoot,
function()
    db = dbConnect("sqlite", "dados.sqlite")
    dbExec(db, "UPDATE DealerShip SET state = ? WHERE state = ?", "Guardado", "Spawnado")
    dbExec(db, "CREATE TABLE IF NOT EXISTS DealerShip(account, model, state, dataVeh, dataTuning, identity)")
    dbExec(db, "CREATE TABLE IF NOT EXISTS StockDealerShip(model, quantity)")
    dbQuery(saveQuery, db, "SELECT * FROM DealerShip")
    dbQuery(saveStock, db, "SELECT * FROM StockDealerShip")
    if config["Mensagem Start"] then
        outputDebugString("["..getResourceName(getThisResource()).."] Startado com sucesso, qualquer bug contacte zJoaoFtw_#5562!")
    end
    for i, v in ipairs(config["Marker's"]) do
        markersCustom[i] = createMarker(v[1], v[2], v[3], "cylinder", 1.1, 0, 0, 0, 0)
        if v[4] == 'dealership' then
            setElementData(markersCustom[i], "markerData", {title = "Consecionaria ULGEDEV", desc = "¡Compre aquí su vehículo!", icon = "exchange"})
        elseif v[4] == 'garage' then 
            setElementData(markersCustom[i], "markerData", {title = "Garage", desc = "¡Recoja o guarde aquí su vehículo!", icon = "garage"})
        elseif v[4] == 'detran' then 
            setElementData(markersCustom[i], "markerData", {title = "Registro del automotor", desc = "¡Pague los impuestos de su vehículo!", icon = "office"})
        end
        blip_create[i] = createBlipAttachedTo(markersCustom[i], v[4] == "dealership" and 55 or v[4] == "garage" and 53 or 24)
        addEventHandler("onMarkerHit", markersCustom[i],
        function(player, dim)
            if player and isElement(player) and getElementType(player) == "player" and dim and source == markersCustom[i] then
                if v[4] == "garage" then
                    if tableGarage[puxarConta(player)] and #tableGarage[puxarConta(player)] > 0 then
                        triggerClientEvent(player, "JOAO.openDealerShip", player, v[4], i)
                    else
                        notifyS(player, "¡No tienes ningún vehículo!", "error")
                    end
                elseif v[4] == "detran" then
                    if tableGarage[puxarConta(player)] and #tableGarage[puxarConta(player)] > 0 then
                        triggerClientEvent(player, "JOAO.openDealerShip", player, v[4], i)
                    else
                        notifyS(player, "¡No tienes ningún vehículo!", "error")
                    end
                else
                    triggerClientEvent(player, "JOAO.openDealerShip", player, v[4], i)
                end
                sendData(player, v[4])
            end
        end)
    end
    setTimer(function()
        for i, v in pairs(tableGarage) do
            for k, b in ipairs(tableGarage[i]) do
                local jsonDetails = fromJSON(b.dataVeh)
                if jsonDetails.rent then
                    if getRealTime().timestamp >= jsonDetails.rent then
                        table.remove(tableGarage[i], k)
                        dbExec(db, "DELETE FROM DealerShip WHERE account = ? AND model = ?", i, b.model)
                    end
                end
            end
        end
    end, 1000, 0)
    colshape = createColSphere(-2651.584, -14.406, 55.498, 100)
end)

addEventHandler("onPlayerLogin", root,
function(_, account)
    local nameAccount = getAccountName(account)
    if tableGarage[nameAccount] then
        local vehicleExistsRent = isVehicleExistsRent(nameAccount)
        if vehicleExistsRent then
            notifyS(source, "El alquiler del vehículo "..vehicleExistsRent.name.." vencerá en 1 día!", "info")
        end
    end
end)

addCommandHandler("stockauto",
function(player, cmd, id, qnt)
    if aclGetGroup("Console") and isObjectInACLGroup("user."..puxarConta(player), aclGetGroup("Console")) then
        local id = tonumber(id)
        local qnt = tonumber(qnt)
        if id and qnt then
            if stockDealerShip[id] then
                stockDealerShip[id].quantity = stockDealerShip[id].quantity + qnt
                dbExec(db, "UPDATE StockDealerShip SET quantity = ? WHERE model = ?", stockDealerShip[id].quantity, id)
                notifyS(player, "Agregaste "..qnt.."x de stock para el vehículo ID= "..id, "success")
            else
                stockDealerShip[id] = {
                    model = id,
                    quantity = qnt,
                }
                dbExec(db, "INSERT INTO StockDealerShip(model, quantity) VALUES(?,?)", id, qnt)
                notifyS(player, "Agregaste "..qnt.."x de stock para el vehículo x de stock para el vehículo ID= "..id, "success")
            end
        else
            notifyS(player, "Utiliza /stockauto [ID] [CAN]", "info")
        end
    end
end)

addEvent("JOAO.rentVehicle", true)
addEventHandler("JOAO.rentVehicle", root,
function(player, tableVehicle, typeVehicle, days)
    if tableVehicle and typeVehicle and days then
        if not stockDealerShip[tableVehicle.ID] then notifyS(player, "¡Sin stock!", "error") return end
        if stockDealerShip[tableVehicle.ID].quantity <= 0 then notifyS(player, "¡Sin stock!", "error") return end
        if getPlayerMoney(player) < (tableVehicle["Price"].rent*days) then
            notifyS(player, "¡Te falta dinero!", "error")
            return
        end
        local vehicleExists = isVehicleExists(player, tableVehicle.ID)
        if vehicleExists then
            notifyS(player, "¡Ya compraste este vehículo!", "error")
            return
        end
        takePlayerMoney(player, (tableVehicle["Price"].rent*days))
        if not tableGarage[puxarConta(player)] then tableGarage[puxarConta(player)] = {} end
        local identityCar = gerarCode(6)
        dataVeh = {
            typeBuy = "money",
            color = {255, 255, 255},
            price = (tableVehicle["Price"].rent*days),
            engine = 1000,
            fuel = 100,
            plate = "BVR-"..gerarCodigo(4),
            name = tableVehicle.Name,
            tableVeh = tableVehicle,
            tax = (getRealTime().timestamp+604800),
            safe = false,
            rent = (getRealTime().timestamp+(days*86400)),
        }
        table.insert(tableGarage[puxarConta(player)], {
            account = puxarConta(player),
            model = tableVehicle.ID,
            state = "Guardado",
            dataVeh = toJSON(dataVeh),
            dataTuning = nil,
            identity = identityCar,
        })
        exports["LP_inventario"]:giveItem(player, 117, 1, {
            nameItem = " do "..tableVehicle.Name,
            name = puxarNome(player),
            id = puxarID(player),
            account = puxarConta(player),
            identity = identityCar,
        })
        stockDealerShip[tableVehicle.ID].quantity = stockDealerShip[tableVehicle.ID].quantity - 1
        dbExec(db, "UPDATE StockDealerShip SET quantity = ? WHERE model = ?", stockDealerShip[tableVehicle.ID].quantity, tableVehicle.ID)
        dbExec(db, "INSERT INTO DealerShip(account, model, state, dataVeh, dataTuning, identity) VALUES(?,?,?,?,?,?)", puxarConta(player), tableVehicle.ID, "Guardado", toJSON(dataVeh), null, identityCar)
        notifyS(player, "¡Has alquilado un vehículo!", "success")
    end
end)

function syncVehicles(account, vip, timestamp)
    if account and vip and timestamp then
        if not tableGarage[account] then tableGarage[account] = {} end
        local idAccount = exports["vanish_id"]:getIdByConta(account)
        local personage = exports['vanish_characters']:getPersonagem(account)
        if not idAccount then return end
        if config["VIP's"][vip] then
            for i, v in ipairs(config["VIP's"][vip]) do
                local identityCar = gerarCode(6)
                dataVeh = {
                    typeBuy = "money",
                    color = {255, 255, 255},
                    price = 0,
                    engine = 1000,
                    fuel = 100,
                    plate = "BVR-"..gerarCodigo(4),
                    name = v.Name,
                    tableVeh = v,
                    tax = (getRealTime().timestamp+604800),
                    safe = false,
                    rent = timestamp,
                }
                table.insert(tableGarage[account], {
                    account = account,
                    model = v.ID,
                    state = "Guardado",
                    dataVeh = toJSON(dataVeh),
                    dataTuning = nil,
                    identity = identityCar,
                })
                exports["LP_inventario"]:giveDataItem(account, 117, 1, {
                    nameItem = " do "..v.Name,
                    name = personage[1].name..'_'..personage[1].surname,
                    id = idAccount,
                    account = account,
                    identity = identityCar,
                })
                local vehicleExists = isVehicleExistsByAccount(account, v.ID)
                if not vehicleExists then
                    dbExec(db, "INSERT INTO DealerShip(account, model, state, dataVeh, dataTuning, identity) VALUES(?,?,?,?,?,?)", account, v.ID, "Guardado", toJSON(dataVeh), null, identityCar)
                end
            end
        end
    end
end

addEvent("JOAO.detranDealerShip", true)
addEventHandler("JOAO.detranDealerShip", root,
function(player, modelVehicle, typeDetran, vehicleIdentity)
    if modelVehicle and typeDetran then
        if typeDetran == "safe" then
            local indexVehicle, detailsVeh = getDetailsVehicleByIdentity(vehicleIdentity)
            if not detailsVeh then notifyS(player, "¡Ese vehículo no te pertenece!", "error") return end
            if not indexVehicle then notifyS(player, "¡Ese vehículo no te pertenece!", "error") return end
            local tableVehicle = tableGarage[puxarConta(player)][indexVehicle]
            local jsonDetails = fromJSON(tableVehicle.dataVeh)
            if jsonDetails.safe then
                notifyS(player, "¡Has asegurado tu vehículo!", "success")
                return
            end
            local price = (10*jsonDetails.tableVeh["Price"].money/100)
            if getPlayerMoney(player) < price then
                notifyS(player, "¡Te falta dinero!", "error")
                return
            end
            takePlayerMoney(player, price)
            jsonDetails.safe = true
            tableGarage[puxarConta(player)][indexVehicle].dataVeh = toJSON(jsonDetails)
            dbExec(db, "UPDATE DealerShip SET dataVeh = ? WHERE account = ? AND model = ?", tableGarage[puxarConta(player)][indexVehicle].dataVeh, puxarConta(player), modelVehicle)
            notifyS(player, "¡Has asegurado tu vehículo!", "success")
            sendData(player, "detran")
        elseif typeDetran == "tax" then
            local indexVehicle, detailsVeh = getDetailsVehicleByIdentity(vehicleIdentity)
            if not detailsVeh then notifyS(player, "¡Ese vehículo no te pertenece!", "error") return end
            if not indexVehicle then notifyS(player, "¡Ese vehículo no te pertenece!", "error") return end
            local tableVehicle = tableGarage[puxarConta(player)][indexVehicle]
            local jsonDetails = fromJSON(tableVehicle.dataVeh)
            if getRealTime().timestamp < jsonDetails.tax then
                notifyS(player, "¡No es necesario renovar el impuesto!", "success")
                return
            end
            local price = (10*jsonDetails.price/100)
            if getPlayerMoney(player) < price then
                notifyS(player, "¡Te falta dinero!", "error")
                return
            end
            takePlayerMoney(player, price)
            jsonDetails.tax = (getRealTime().timestamp+604800)
            tableGarage[puxarConta(player)][indexVehicle].dataVeh = toJSON(jsonDetails)
            dbExec(db, "UPDATE DealerShip SET dataVeh = ? WHERE account = ? AND model = ?", tableGarage[puxarConta(player)][indexVehicle].dataVeh, puxarConta(player), modelVehicle)
            notifyS(player, "¡Has pagado tus impuestos!", "success")
            sendData(player, "detran")
        elseif typeDetran == "release" then
            local indexVehicle, detailsVeh = getDetailsVehicleByIdentity(vehicleIdentity)
            if not detailsVeh then notifyS(player, "¡Ese vehículo no te pertenece!", "error") return end
            if not indexVehicle then notifyS(player, "¡Ese vehículo no te pertenece!", "error") return end
            local tableVehicle = tableGarage[puxarConta(player)][indexVehicle]
            local jsonDetails = fromJSON(tableVehicle.dataVeh)
            if tableGarage[puxarConta(player)][indexVehicle].state ~= "Recuperar" then
                notifyS(player, "¡No necesitas recuperar tu vehículo!", "success")
                return
            end
            local price = (10*jsonDetails.tableVeh["Price"].money/100)
            if getPlayerMoney(player) < price then
                notifyS(player, "¡Te falta dinero!", "error")
                return
            end
            takePlayerMoney(player, price)
            tableGarage[puxarConta(player)][indexVehicle].state = "Guardado"
            dbExec(db, "UPDATE DealerShip SET state = ? WHERE account = ? AND model = ?", "Guardado", puxarConta(player), modelVehicle)
            notifyS(player, "¡Has recuperado tu vehículo!", "success")
            sendData(player, "detran")
        end
    end
end)

addEvent("JOAO.testDriveDealerShip", true)
addEventHandler("JOAO.testDriveDealerShip", root,
function(player, carTable)
    if carTable then
        if isElement(testDriveCar[player]) then
            notifyS(player, "¡Ya estás haciendo el test de conducción!", "error")
        else
            triggerClientEvent(player, "JOAO.closeDealerShip", player)
            posSave[player] = {getElementPosition(player)}
            rotSave[player] = {getElementRotation(player)}
            dimTest = dimTest + 1
            testDriveCar[player] = createVehicle(carTable.ID, -2662.996, -44.301, 15.21)
            carTest[testDriveCar[player]] = true
            warpPedIntoVehicle(player, testDriveCar[player])
            setElementDimension(testDriveCar[player], dimTest)
            setElementDimension(player, dimTest)
            timerDriver[player] = setTimer(function()
                if isElement(player) then
                    removePedFromVehicle(player)
                    if isElement(testDriveCar[player]) then destroyElement(testDriveCar[player]) end
                    setElementPosition(player, posSave[player][1], posSave[player][2], posSave[player][3])
                    setElementRotation(player, rotSave[player][1], rotSave[player][2], rotSave[player][3])
                    setElementDimension(player, 0)
                    notifyS(player, "¡Se ha acabado la prueba de manejo!", "info")
                end
            end, 30000, 1)
            addEventHandler("onColShapeLeave", colshape,
            function(player)
                if isElement(player) and getElementType(player) == "player" then
                    if isElement(testDriveCar[player]) then
                        if getPedOccupiedVehicle(player) then
                            if isElement(testDriveCar[player]) then destroyElement(testDriveCar[player]) end
                        else
                            if isElement(testDriveCar[player]) then destroyElement(testDriveCar[player]) end
                        end
                        setTimer(function()
                            if isElement(player) then
                                if isTimer(timerDriver[player]) then killTimer(timerDriver[player]) end
                                setElementPosition(player, posSave[player][1], posSave[player][2], posSave[player][3])
                                setElementRotation(player, rotSave[player][1], rotSave[player][2], rotSave[player][3])
                                setElementDimension(player, 0)
                            end
                        end, 1000, 1)
                        notifyS(player, "!Saliste del área de la prueba y fuiste expulsado!", "info")
                    end
                end
            end)
        end
    end
end)

addEvent("JOAO.vehicleDealerShip", true)
addEventHandler("JOAO.vehicleDealerShip", root,
function(player, tableVehicle, typeManage, indexMarker)
    if tableVehicle and typeManage and indexMarker then
        if typeManage == "withdraw" then
            local indexVehicle, detailsVeh = getDetailsVehicleByIdentity(tableVehicle.identity)
            if not detailsVeh then notifyS(player, "¡Ese vehículo no te pertenece!", "error") return end
            if not indexVehicle then notifyS(player, "¡Ese vehículo no te pertenece!", "error") return end
            if detailsVeh.state == "Spawnado" then
                notifyS(player, "¡Ya recogiste ese vehículo!", "error")
                return
            end
            if detailsVeh.state == "Recuperar" then
                notifyS(player, "¡Ese vehículo fue secuestrado por la policía!", "error")
                return
            end
            local existsVehicle = getVehicleExistsByIdentity(tableVehicle.identity)
            if existsVehicle then notifyS(player, "¡Ya recogiste ese vehículo!", "error") return end
            local jsonDetails = fromJSON(detailsVeh.dataVeh)
            if (getRealTime().timestamp >= jsonDetails.tax) then
                notifyS(player, "¡Te falta pagar los impuestos!", "error")
                return
            end
            local positionsGarage = getPositionGarage(indexMarker)
            tableGarage[puxarConta(player)][indexVehicle].state = "Spawnado"
            dbExec(db, "UPDATE DealerShip SET state = ? WHERE identity = ?", "Spawnado", tableVehicle.identity)
            vehicleGarage = createVehicle(detailsVeh.model, positionsGarage.Pos[1], positionsGarage.Pos[2], positionsGarage.Pos[3])
            setElementRotation(vehicleGarage, positionsGarage.Rotation[1], positionsGarage.Rotation[2], positionsGarage.Rotation[3])
            setElementData(vehicleGarage, "JOAO.identityCar", detailsVeh.identity)
            setVehicleColor(vehicleGarage, unpack(jsonDetails.color))
            setElementHealth(vehicleGarage, jsonDetails.engine)
            setElementData(vehicleGarage, "JOAO.fuel", jsonDetails.fuel)
            setVehiclePlateText(vehicleGarage, jsonDetails.plate)
            setElementData(vehicleGarage, "JOAO.detailsVeh", {
                identity = detailsVeh.identity,
                account = puxarConta(player),
            })
            notifyS(player, "¡Has recogido tu vehículo!", "success")
        elseif typeManage == "save" then
            local existsVehicle = getVehicleExistsByIdentity(tableVehicle.identity)
            if not existsVehicle then notifyS(player, "Esse carro não está spawnado!", "error") return end
            local distance = getDistanceBetweenPoints3D(Vector3(unpack({getElementPosition(existsVehicle)})), Vector3(unpack({getElementPosition(player)})))
            if distance > 5 then
                notifyS(player, "¡Debes estar cerca de este vehículo!", "error")
                return
            end
            if isElement(existsVehicle) then destroyElement(existsVehicle) end
            notifyS(player, "¡Guardaste tu vehículo!", "success")
        end
    end
end)

function dataSave(vehicleElement)
    db = dbConnect("sqlite", "dados.sqlite")
    local elementDetails = (getElementData(vehicleElement, "JOAO.detailsVeh") or false)
    if elementDetails then
        local indexVehicle, detailsVeh = getDetailsVehicleByIdentity(elementDetails.identity)
        if not indexVehicle then return end
        if not detailsVeh then return end
        if tableGarage[elementDetails.account][indexVehicle].state == "Recuperar" then
            local jsonDetails = fromJSON(detailsVeh.dataVeh)
            jsonDetails.engine = getElementHealth(vehicleElement)
            jsonDetails.fuel = (getElementData(vehicleElement, "JOAO.fuel") or 0)
            jsonDetails.color = ({getVehicleColor(vehicleElement, true)})
            tableGarage[elementDetails.account][indexVehicle].dataVeh = toJSON(jsonDetails)
            dbExec(db, "UPDATE DealerShip SET dataVeh = ? WHERE identity = ?", tableGarage[elementDetails.account][indexVehicle].dataVeh, elementDetails.identity)
        else
            local jsonDetails = fromJSON(detailsVeh.dataVeh)
            jsonDetails.engine = getElementHealth(vehicleElement)
            jsonDetails.fuel = (getElementData(vehicleElement, "JOAO.fuel") or 0)
            jsonDetails.color = ({getVehicleColor(vehicleElement, true)})
            tableGarage[elementDetails.account][indexVehicle].dataVeh = toJSON(jsonDetails)
            tableGarage[elementDetails.account][indexVehicle].state = "Guardado"
            dbExec(db, "UPDATE DealerShip SET state = ?, dataVeh = ? WHERE identity = ?", "Guardado", tableGarage[elementDetails.account][indexVehicle].dataVeh, elementDetails.identity)
        end
    end
end

blipVehicle = {}

function findVehicle(player, idVehicle)
    local existsVehicle = getVehicleExistsByAccount(puxarConta(player))
    if existsVehicle then
        if (getElementModel(existsVehicle) == idVehicle) then
            if not isElement(blipVehicle[player]) then
                local pos = {getElementPosition(existsVehicle)}
                blipVehicle[player] = createBlip(pos[1], pos[2], pos[3], 41)
                setElementVisibleTo(blipVehicle[player], root, false)
                setElementVisibleTo(blipVehicle[player], player, true)
                setTimer(function()
                    if isElement(blipVehicle[player]) then destroyElement(blipVehicle[player]) end
                end, 1*60000, 1)
                return true
            end
        end
    end
    return false
end

function getVehicleExistsByAccount(account)
    for i, v in ipairs(getElementsByType("vehicle")) do
        local elementVehicle = (getElementData(v, "JOAO.detailsVeh") or false)
        if isElement(v) and elementVehicle and elementVehicle.account == account then
            return v
        end
    end
    return false
end

addEvent("JOAO.buyVehicle", true)
addEventHandler("JOAO.buyVehicle", root,
function(player, tableVehicle, colorTable, typeVehicle, typeMoney)
    if not colorTable then colorTable = {255, 255, 255} end
    if tableVehicle and colorTable and typeVehicle and typeMoney then
        if not stockDealerShip[tableVehicle.ID] then notifyS(player, "Estoque indisponível!", "error") return end
        if stockDealerShip[tableVehicle.ID].quantity <= 0 then notifyS(player, "Estoque indisponível!", "error") return end
        if typeMoney == "money" then
            if getPlayerMoney(player) < tableVehicle["Price"].money then
                notifyS(player, "¡Te falta dinero!", "error")
                return
            end
            local vehicleExists = isVehicleExists(player, tableVehicle.ID)
            if vehicleExists then
                notifyS(player, "¡Ya eres dueño de este vehículo!", "error")
                return
            end
            takePlayerMoney(player, tableVehicle["Price"].money)
            if not tableGarage[puxarConta(player)] then tableGarage[puxarConta(player)] = {} end
            local identityCar = gerarCode(6)
            local plate = "BVR-"..gerarCodigo(4)
            dataVeh = {
                typeBuy = typeMoney,
                color = colorTable,
                price = tableVehicle["Price"].money,
                engine = 1000,
                fuel = 100,
                plate = plate,
                name = tableVehicle.Name,
                tableVeh = tableVehicle,
                tax = (getRealTime().timestamp+604800),
                safe = false,
                rent = false,
            }
            table.insert(tableGarage[puxarConta(player)], {
                account = puxarConta(player),
                model = tableVehicle.ID,
                state = "Guardado",
                dataVeh = toJSON(dataVeh),
                dataTuning = nil,
                identity = identityCar,
            })
            exports["LP_inventario"]:giveItem(player, 117, 1, {
                nameItem = " do "..tableVehicle.Name,
                name = puxarNome(player),
                id = puxarID(player),
                account = puxarConta(player),
                identity = identityCar,
            })
            stockDealerShip[tableVehicle.ID].quantity = stockDealerShip[tableVehicle.ID].quantity - 1
            dbExec(db, "UPDATE StockDealerShip SET quantity = ? WHERE model = ?", stockDealerShip[tableVehicle.ID].quantity, tableVehicle.ID)
            dbExec(db, "INSERT INTO DealerShip(account, model, state, dataVeh, dataTuning, identity) VALUES(?,?,?,?,?,?)", puxarConta(player), tableVehicle.ID, "Guardado", toJSON(dataVeh), null, identityCar)
            notifyS(player, "¡Has comprado un vehículo!", "success")
        elseif typeMoney == "points" then
            local currentPoints = (getElementData(player, "vpoints") or 0)
            if currentPoints < tableVehicle["Price"].points then
                notifyS(player, "¡Te falta dinero!", "error")
                return
            end
            local vehicleExists = isVehicleExists(player, tableVehicle.ID)
            if vehicleExists then
                notifyS(player, "¡Ya eres dueño de este vehículo!", "error")
                return
            end
            setElementData(player, "vpoints", currentPoints - tableVehicle["Price"].points)
            if not tableGarage[puxarConta(player)] then tableGarage[puxarConta(player)] = {} end
            local identityCar = gerarCode(6)
            local plate = "BVR-"..gerarCodigo(4)
            dataVeh = {
                typeBuy = typeMoney,
                color = colorTable,
                price = tableVehicle["Price"].points,
                engine = 1000,
                fuel = 100,
                plate = plate,
                name = tableVehicle.Name,
                tableVeh = tableVehicle,
                tax = (getRealTime().timestamp+604800),
                safe = false,
                rent = false
            }
            table.insert(tableGarage[puxarConta(player)], {
                account = puxarConta(player),
                model = tableVehicle.ID,
                state = "Guardado",
                dataVeh = toJSON(dataVeh),
                dataTuning = nil,
                identity = identityCar,
            })
            exports["LP_inventario"]:giveItem(player, 117, 1, {
                nameItem = " do "..tableVehicle.Name,
                name = puxarNome(player),
                id = puxarID(player),
                account = puxarConta(player),
                identity = identityCar,
            })
            stockDealerShip[tableVehicle.ID].quantity = stockDealerShip[tableVehicle.ID].quantity - 1
            dbExec(db, "UPDATE StockDealerShip SET quantity = ? WHERE model = ?", stockDealerShip[tableVehicle.ID].quantity, tableVehicle.ID)
            dbExec(db, "INSERT INTO DealerShip(account, model, state, dataVeh, dataTuning, identity) VALUES(?,?,?,?,?,?)", puxarConta(player), tableVehicle.ID, "Guardado", toJSON(dataVeh), null, identityCar)
            notifyS(player, "¡Has comprado un vehículo!", "success")
        end
        sendData(player, "dealership")
    end
end)

proposalPending = {}
timerProposal = {}

addEvent("JOAO.mailProposal", true)
addEventHandler("JOAO.mailProposal", root,
function(player, vehicleTable, value, id)
    if vehicleTable and value and id then
        local receiver = getPlayerFromID(id)
        local indexVehicle, detailsVeh = getDetailsVehicleByIdentity(vehicleTable.identity)
        if not detailsVeh then notifyS(player, "¡Ese vehículo no te pertenece!", "error") return end
        if not indexVehicle then notifyS(player, "¡Ese vehículo no te pertenece!", "error") return end
        if not isElement(receiver) then
            notifyS(player, "¡El comprador no está conectado!", "error")
            return
        end
        local distance = getDistanceBetweenPoints3D(Vector3(unpack({getElementPosition(player)})), Vector3(unpack({getElementPosition(receiver)})))
        if distance > 5 then
            notifyS(player, "¡El comprador está demiasiado lejos!", "error")
            return
        end
        if tableGarage[puxarConta(player)][indexVehicle].state == "Recuperar" then
            notifyS(player, "¡Debes recuperar el vehículo antes de venderlo!", "success")
            return
        end
        if proposalPending[player] then
            notifyS(player, "¡Tienes una venta pendiente!", "error")
            return
        end
        if proposalPending[receiver] then
            notifyS(player, "¡El comprador tiene una venta pendiente!", "error")
            return
        end
        if player == receiver then notifyS(player, "¡No puedes venderte a ti mismo!", "error") return end
        proposalPending[player] = {
            element = receiver,
        }
        proposalPending[receiver] = {
            element = player,
            value = value,
            vehicleTable = vehicleTable,
        }
        timerProposal[player] = setTimer(function()
            if isElement(player) then
                timerProposal[player] = nil
                proposalPending[player] = nil
            end
            if isElement(receiver) then
                proposalPending[receiver] = nil
            end
        end, 1*60000, 1)
        notifyS(player, "Le has ofrecido tu vehículo al jugador", "success")
        notifyS(receiver, "Te quieren vender un vehículo: /aceptar vehiculo o /negar vehiculo", "success")
    end
end)

addEvent("JOAO.sellDealerShip", true)
addEventHandler("JOAO.sellDealerShip", root,
function(player, vehicleTable)
    if vehicleTable then
        local indexVehicle, detailsVeh = getDetailsVehicleByIdentity(vehicleTable.identity)
        if not detailsVeh then notifyS(player, "¡Ese vehículo no te pertenece!", "error") return end
        if not indexVehicle then notifyS(player, "¡Ese vehículo no te pertenece!", "error") return end
        local elementVehicle = getVehicleExistsByAccount(puxarConta(player))
        if tableGarage[puxarConta(player)][indexVehicle].state == "Spawnado" then
            notifyS(player, "Esse veículo está spawnado!", "error")
            return
        end
        if tableGarage[puxarConta(player)][indexVehicle].state == "Recuperar" then
            notifyS(player, "¡Debes recuperar el vehículo antes de venderlo!", "success")
            return
        end
        local data = fromJSON(tableGarage[puxarConta(player)][indexVehicle].dataVeh)
        if (getRealTime().timestamp >= data.tax) then
            notifyS(player, "¡El vehículo tiene impuestos por pagar!", "error")
            return
        end
        if data.typeBuy == "money" then
            local price = (10*data.price/100)
            givePlayerMoney(player, price)
            iprint("El jugador "..puxarNome(player).." #"..puxarID(player).." vendió el carro ID= "..vehicleTable.model.." por $ "..formatNumber(price))
        elseif data.typeBuy == "points" then
            local currentData = (getElementData(player, "vpoints") or 0)
            local price = (10*data.price/100)
            setElementData(player, "vpoints", currentData + price)
            iprint("El jugador "..puxarNome(player).." #"..puxarID(player).." vendió el carro ID= "..vehicleTable.model.." por $ "..formatNumber(price))
        end
        if elementVehicle and isElement(elementVehicle) then destroyElement(elementVehicle) end
        exports["LP_inventario"]:takeItem(player, tostring(vehicleTable.identity), 1)
        exports["LP_inventario"]:takeItemByPlate(player, tostring(data.plate), 1)
        stockDealerShip[vehicleTable.model].quantity = stockDealerShip[vehicleTable.model].quantity + 1
        dbExec(db, "UPDATE StockDealerShip SET quantity = ? WHERE model = ?", stockDealerShip[vehicleTable.model].quantity, vehicleTable.model)
        dbExec(db, "DELETE FROM DealerShip WHERE account = ? AND model = ?", puxarConta(player), tableGarage[puxarConta(player)][indexVehicle].model)
        table.remove(tableGarage[puxarConta(player)], indexVehicle)
        sendData(player, "garage")
        triggerClientEvent(player, "JOAO.closeAllDealerShip", player)
        notifyS(player, "¡Has vendido el vehículo con éxito!", "success")
    end
end)

addEventHandler("onPlayerQuit", root,
function()
    if proposalPending[source] then
        if isTimer(timerProposal[proposalPending[source].element]) then killTimer(timerProposal[proposalPending[source].element]) end
        proposalPending[proposalPending[source].element] = nil
        proposalPending[source] = nil
    end
end)

addCommandHandler("aceitar",
function(player, cmd, subCommand)
    if subCommand then
        if subCommand == "vehicle" then
            if proposalPending[player] then
                local seller = (proposalPending[player].element)
                if not isElement(seller) then
                    notifyS(player, "El vendedor no está online, venta cancelada", "error")
                    proposalPending[player] = nil
                    return
                end
                if getPlayerMoney(player) < proposalPending[player].value then
                    notifyS(player, "¡Te falta dinero!", "error")
                    return
                end
                local vehicleVerify = getVehicleExistsByModel(proposalPending[player].vehicleTable.model, proposalPending[player].vehicleTable.account)
                local vehicleExistsModel = getVehicleExistsByModel(proposalPending[player].vehicleTable.model, puxarConta(player))
                local existsVeh = getVehicleExistsByAccount(proposalPending[player].vehicleTable.account)
                if isElement(existsVeh) then destroyElement(existsVeh) end
                if not vehicleVerify then return end
                if vehicleExistsModel then 
                    notifyS(player, "¡Ya tienes este vehículo!", "error") 
                    proposalPending[player] = nil
                    proposalPending[seller] = nil
                    return 
                end
                local data = fromJSON(tableGarage[puxarConta(seller)][vehicleVerify].dataVeh)
                takePlayerMoney(player, proposalPending[player].value)
                givePlayerMoney(player, proposalPending[player].value)
                dbExec(db, "UPDATE DealerShip SET account = ?, state = ? WHERE account = ? AND model = ?", puxarConta(player), "Guardado", tableGarage[puxarConta(seller)][vehicleVerify].account, tableGarage[puxarConta(seller)][vehicleVerify].model)
                if not tableGarage[puxarConta(player)] then tableGarage[puxarConta(player)] = {} end
                tableGarage[puxarConta(seller)][vehicleVerify].account = puxarConta(player)
                table.insert(tableGarage[puxarConta(player)], {
                    account = puxarConta(player),
                    model = tableGarage[puxarConta(seller)][vehicleVerify].model,
                    state = "Guardado",
                    dataVeh = tableGarage[puxarConta(seller)][vehicleVerify].dataVeh,
                    dataTuning = tableGarage[puxarConta(seller)][vehicleVerify].dataTuning,
                    identity = tableGarage[puxarConta(seller)][vehicleVerify].identity,
                })
                exports["LP_inventario"]:takeItem(seller, tostring(tableGarage[puxarConta(seller)][vehicleVerify].identity), 1)
                exports["LP_inventario"]:takeItemByPlate(seller, tostring(data.plate), 1)
                exports["LP_inventario"]:giveItem(player, 117, 1, {
                    nameItem = " do "..data.name,
                    name = puxarNome(player),
                    id = puxarID(player),
                    account = puxarConta(player),
                    identity = tableGarage[puxarConta(seller)][vehicleVerify].identity,
                })
                table.remove(tableGarage[puxarConta(seller)], vehicleVerify)
                triggerClientEvent(player, "JOAO.closeAllDealerShip", player)
                triggerClientEvent(seller, "JOAO.closeAllDealerShip", seller)
                notifyS(seller, "Has vendido tu vehículo", "success")
                notifyS(player, "Has finalizado tu compra", "success")
                proposalPending[player] = nil
                proposalPending[seller] = nil
                if isTimer(timerProposal[seller]) then killTimer(timerProposal[seller]) end
            else
                notifyS(player, "¡No tienes propuestas pendientes!", "error")
            end
        end
    end
end)

addCommandHandler("negar",
function(player, cmd, subCommand)
    if subCommand then
        if subCommand == "vehicle" then
            if proposalPending[player] then
                local seller = (proposalPending[player].element)
                if not isElement(seller) then
                    notifyS(player, "¡El vendedor no está conectado, propuesta cancelada!", "error")
                    proposalPending[player] = nil
                    return
                end
                notifyS(seller, "¡Venta cancelada!", "success")
                notifyS(player, "¡Compra cancelada!", "success")
                proposalPending[player] = nil
                proposalPending[seller] = nil
                if isTimer(timerProposal[seller]) then killTimer(timerProposal[seller]) end
            else
                notifyS(player, "¡No tienes propuestas pendientes!!", "error")
            end
        end
    end
end)

setTimer(function() 
    for _, vehicle in ipairs(getElementsByType('vehicle')) do
        if vehicle and isElement(vehicle) and getElementType(vehicle) == "vehicle" and isElementInWater(vehicle) and getVehicleType(vehicle) ~= "Boat" then
            local ownerAccount = (getElementData(vehicle, "JOAO.detailsVeh") or false)
            if (getElementData(vehicle, "JOAO.identityCar") or false) and ownerAccount then
                local indexVehicle, detailsVeh = getDetailsVehicleByIdentity((getElementData(vehicle, "JOAO.identityCar") or false))
                if not detailsVeh then return end
                if not indexVehicle then return end
                dbExec(db, 'UPDATE DealerShip SET state = ? WHERE identity = ?', 'Recuperar', (getElementData(vehicle, "JOAO.identityCar") or false))
                tableGarage[ownerAccount.account][indexVehicle].state = "Recuperar"
                destroyElement(vehicle)
            end
        end
    end
end, 60000, 0)

addEventHandler("onVehicleExplode", root,
function()
    local ownerAccount = (getElementData(source, "JOAO.detailsVeh") or false)
    if (getElementData(source, "JOAO.identityCar") or false) and ownerAccount then
        local indexVehicle, detailsVeh = getDetailsVehicleByIdentity((getElementData(source, "JOAO.identityCar") or false))
        if not detailsVeh then return end
        if not indexVehicle then return end
        dbExec(db, 'UPDATE DealerShip SET state = ? WHERE identity = ?', 'Recuperar', (getElementData(source, "JOAO.identityCar") or false))
        tableGarage[ownerAccount.account][indexVehicle].state = "Recuperar"
        destroyElement(source)
    end
end)

function elementDestroy()
    if (getElementType(source) == 'vehicle') then 
        dataSave(source)
        for i=0, 3 do
            local player = getVehicleOccupant(source, i)
            if (player and isElement(player) and getElementType(player) == 'player') then
                if (getElementData(player, 'JOAO.belt') or false) then
                    setElementData(player, "JOAO.belt", false)
                end
            end
        end
    end
end
addEventHandler('onElementDestroy', root, elementDestroy)

function sendData(player, typeGarage)
    if typeGarage == "garage" then
        triggerClientEvent(player, "JOAO.dataDealerShip", player, tableGarage[puxarConta(player)], "garage")
    elseif typeGarage == "detran" then
        triggerClientEvent(player, "JOAO.dataDealerShip", player, tableGarage[puxarConta(player)], "detran", getRealTime().timestamp)
    elseif typeGarage == "dealership" then
        triggerClientEvent(player, "JOAO.dataDealerShip", player, stockDealerShip, "dealership")
    end
end

function saveStock(queryTable)
    local result = dbPoll(queryTable, 0)
    for i=1, #result do
        local row = result[i]
        stockDealerShip[row.model] = row
    end
end

function saveQuery(queryTable)
    local result = dbPoll(queryTable, 0)
    for i=1, #result do
        local row = result[i]
        if not tableGarage[row.account] then tableGarage[row.account] = {} end
        table.insert(tableGarage[row.account], row)
    end
end

function getMyVehicles(player)
    tableVehicles = {}
    if tableGarage[puxarConta(player)] then
        for i, v in ipairs(tableGarage[puxarConta(player)]) do
            table.insert(tableVehicles, v)
        end
    end
    return tableVehicles
end

function gerarCodigo(qntLetras)
    Letters = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0'}
    sas = ''
    for i=1, qntLetras do
        sas = sas ..Letters[math.random(#Letters)]
    end
    return sas
end

function gerarCode(numberGerar)
    Letters = {'a', 'A', 'b', 'B', 'c', 'C', 'd', 'D', 'e', 'E', 'f', 'F', 'g', 'G', 'h', 'H', 'i', 'I', 'j', 'J', 'k', 'K', 'l', 'L', 'm', 'M', 'n', 'N', 'o', 'O', 'p', 'P', 'q', 'Q', 'r', 'R', 's', 'S', 't', 'T', 'u', 'U', 'v', 'V', 'w', 'W', 'x', 'X', 'y', 'Y', 'z', 'Z', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'}
    sas = ''
    for i=1, numberGerar do
        sas = sas ..Letters[math.random(#Letters)]
    end
    return sas
end

function getVehicleByPlate(plate)
    for i, v in pairs(tableGarage) do
        for k, b in ipairs(tableGarage[i]) do
            local jsonRemove = fromJSON(b.dataVeh)
            if jsonRemove.plate == plate then
                local id = exports["vanish_id"]:getIdByConta(b.account)
                b.number = "0000-0000"
                b.id = id
                b.photo = exports["vanish_identity"]:getPhoto(b.account)
                return b
            end
        end
    end
    return false
end

function getVehiclesSeize()
    tableSeizes = {}
    for i, v in pairs(tableGarage) do
        for k, b in ipairs(tableGarage[i]) do
            if b.state == "Apreendido" then
                local id = exports["vanish_id"]:getIdByConta(b.account)
                b.number = "0000-0000"
                b.id = id
                b.photo = false
                table.insert(tableSeizes, b)
            end
        end
    end
    return tableSeizes
end

function setVehicleState(identity, state)
    for i, v in pairs(tableGarage) do
        for k, b in ipairs(tableGarage[i]) do
            if b.identity == identity then
                tableGarage[i][k].state = state
                dbExec(db, "UPDATE DealerShip SET state = ? WHERE identity = ?", state, identity)
                return true
            end
        end
    end
    return false
end

function isVehicleExists(player, id)
    if tableGarage[puxarConta(player)] then
        for i, v in ipairs(tableGarage[puxarConta(player)]) do
            if v.model == id then
                return true
            end
        end
    end
    return false
end

function isVehicleExistsByAccount(account, id)
    if tableGarage[account] then
        for i, v in ipairs(tableGarage[account]) do
            if v.model == id then
                return true
            end
        end
    end
    return false
end

function getPositionGarage(index)
    if config["Data garage's"][index] then
        return config["Data garage's"][index]
    end
    return {Pos = {0, 0, 0}, Rot = {0, 0, 0}}
end

function isGarageProx(player)
    for i, v in ipairs(config["Marker's"]) do
        if v[4] == 'garage' then
            local x, y, z = getElementPosition(player)
            if getDistanceBetweenPoints3D(x, y, z, v[1], v[2], v[3]) <= 10 then
                return true
            end
        end
    end
    return false
end

function getPlayerFromID(id)
    if (id) then
        for i, v in ipairs(getElementsByType("player")) do
            if not isGuestAccount(getPlayerAccount(v)) then
                if (getElementData(v, "ID") == tonumber(id)) then
                    return v
                end
            end
        end
    end
    return false
end

function getCarProx(player)
    local posv = {getElementPosition(player)}
    for i, v in ipairs(getElementsByType('vehicle')) do
        local pos = {getElementPosition(v)}
        if (getDistanceBetweenPoints3D(posv[1], posv[2], posv[3], pos[1], pos[2], pos[3]) < 5) then
            if ((getElementData(v, "JOAO.identityCar") or false)) then
                return v
            end
        end
    end
    return false
end

function isVehicleExistsRent(account)
    if tableGarage[account] then
        for i, v in ipairs(tableGarage[account]) do
            local jsonDetails = fromJSON(v.dataVeh)
            if jsonDetails.rent then
                if (getRealTime().timestamp+86400) >= jsonDetails.rent then
                    return {name = jsonDetails.name}
                end
            end
        end
    end
    return false
end

function getDetailsVehicleByIdentity(identity)
    for i, v in pairs(tableGarage) do
        for k, b in ipairs(tableGarage[i]) do
            if b.identity == identity then
                return k, b
            end
        end
    end
    return false, false
end

function getVehicleExistsByIdentity(identity)
    for i, v in ipairs(getElementsByType("vehicle")) do
        if isElement(v) and (getElementData(v, "JOAO.identityCar") or false) == identity then
            return v
        end
    end
    return false
end

function getVehiclePrice(model, type)
    if (model) and (type) then
        if type == 'Automobile' then 
            type = 'car'
        elseif type == 'Bike' then 
            type = 'motorbike'
        end
        if type == 'car' or type == 'motorbike' then
            for i,v in ipairs(config['Vehicles'][type]) do
                if v.ID == model then
                    return v.Price.money
                end
            end
        end
    end
    return 0
end

function getVehicleExistsByModel(model, account)
    if tableGarage[account] then
        for i, v in ipairs(tableGarage[account]) do
            if v.model == model then
                return i
            end
        end
    end
    return false
end