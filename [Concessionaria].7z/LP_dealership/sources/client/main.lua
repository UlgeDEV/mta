local font = dxCreateFont("files/fonts/medium.ttf", 12)
local font2 = dxCreateFont("files/fonts/medium.ttf", 9)
local font3 = dxCreateFont("files/fonts/medium.ttf", 8)
local font4 = dxCreateFont("files/fonts/semibold.ttf", 7)
local font5 = dxCreateFont("files/fonts/semibold.ttf", 8)
local font6 = dxCreateFont("files/fonts/medium.ttf", 10)

addEventHandler("onClientResourceStop", resourceRoot,
function()
    destroyPreview()
end)

edits = {}


detransTable = {["Pagar imposto"] = {}, ["Pagar seguro"] = {}, ["Liberar veículo"] = {}}
stockDealerShip = {}

function dx()
    if window == "dealership" then
        dxDrawImage(300, 154, 765, 420, "files/imgs/dealership.png")
        dxDrawText("Concesionaria ULGEDEV", 360, 185, 279, 22, tocolor(255, 255, 255, 255), 1.00, font6, "left", "center", false, false, false, false, false)
        dxDrawText("Bienvenido/a, "..puxarNome(localPlayer), 331, 207, 279, 22, tocolor(255, 255, 255, 35), 1.00, font2, "left", "center", false, false, false, false, false)
        if (isMouseInPosition(714, 197, 37, 16) and not buyVehicle and not rentVehicle) or typeVehicle == "car" then
            dxDrawText("Autos", 714, 197, 37, 16, tocolor(173, 146, 255, 255), 1.00, font2, "center", "center", false, false, false, false, false)
            dxDrawImage(729, 222, 8, 8, "files/imgs/ellipse.png")
        else
            dxDrawText("Autos", 714, 197, 37, 16, tocolor(255, 255, 255, 20), 1.00, font2, "center", "center", false, false, false, false, false)
        end
        if (isMouseInPosition(769, 197, 36, 16) and not buyVehicle and not rentVehicle) or typeVehicle == "motorbike" then
            dxDrawText("Motos", 769, 197, 36, 16, tocolor(173, 146, 255, 255), 1.00, font2, "center", "center", false, false, false, false, false)
            dxDrawImage(783, 222, 8, 8, "files/imgs/ellipse.png")
        else
            dxDrawText("Motos", 769, 197, 36, 16, tocolor(255, 255, 255, 20), 1.00, font2, "center", "center", false, false, false, false, false)
        end
        if (isMouseInPosition(823, 197, 62, 16) and not buyVehicle and not rentVehicle) or typeVehicle == "trucks" then
            dxDrawText("Camiones", 823, 197, 62, 16, tocolor(173, 146, 255, 255), 1.00, font2, "center", "center", false, false, false, false, false)
            dxDrawImage(850, 222, 8, 8, "files/imgs/ellipse.png")
        else
            dxDrawText("Camiones", 823, 197, 62, 16, tocolor(255, 255, 255, 20), 1.00, font2, "center", "center", false, false, false, false, false)
        end
        if (isMouseInPosition(903, 197, 39, 16) and not buyVehicle and not rentVehicle) or typeVehicle == "boats" then
            dxDrawText("Barcos", 903, 197, 39, 16, tocolor(173, 146, 255, 255), 1.00, font2, "center", "center", false, false, false, false, false)
            dxDrawImage(919, 222, 8, 8, "files/imgs/ellipse.png")
        else
            dxDrawText("Barcos", 903, 197, 39, 16, tocolor(255, 255, 255, 20), 1.00, font2, "center", "center", false, false, false, false, false)
        end
        if (isMouseInPosition(960, 197, 71, 16) and not buyVehicle and not rentVehicle) or typeVehicle == "helicopters" then
            dxDrawText("Helicópteros", 960, 197, 71, 16, tocolor(173, 146, 255, 255), 1.00, font2, "center", "center", false, false, false, false, false)
            dxDrawImage(992, 222, 8, 8, "files/imgs/ellipse.png")
        else
            dxDrawText("Helicópteros", 960, 197, 71, 16, tocolor(255, 255, 255, 20), 1.00, font2, "center", "center", false, false, false, false, false)
        end
        dxDrawText("Vehículo", 345, 280, 121, 13, tocolor(255, 255, 255, 35), 1.00, font2, "left", "center", true, false, false, false, false)
        dxDrawText(config["Vehicles"][typeVehicle][vehicleSelect].Name, 345, 293, 121, 13, tocolor(255, 255, 255, 90), 1.00, font3, "left", "center", true, false, false, false, false)
        dxDrawText("Valor del vehículo", 531, 280, 121, 13, tocolor(255, 255, 255, 35), 1.00, font2, "left", "center", true, false, false, false, false)
        dxDrawText("$"..formatNumber(config["Vehicles"][typeVehicle][vehicleSelect]["Price"].money), 531, 293, 121, 13, tocolor(255, 255, 255, 90), 1.00, font3, "left", "center", true, false, false, false, false)
        dxDrawText("Valor del vehículo", 717, 280, 121, 13, tocolor(255, 255, 255, 35), 1.00, font2, "left", "center", true, false, false, false, false)
        dxDrawText("C$ "..formatNumber(config["Vehicles"][typeVehicle][vehicleSelect]["Price"].points), 717, 293, 121, 13, tocolor(255, 255, 255, 90), 1.00, font3, "left", "center", true, false, false, false, false)
        dxDrawText("Stock", 903, 280, 121, 13, tocolor(255, 255, 255, 35), 1.00, font2, "left", "center", true, false, false, false, false)
        dxDrawText(stockDealerShip[config["Vehicles"][typeVehicle][vehicleSelect].ID] and stockDealerShip[config["Vehicles"][typeVehicle][vehicleSelect].ID].quantity.." x" or "0x", 903, 293, 121, 13, tocolor(255, 255, 255, 90), 1.00, font3, "left", "center", true, false, false, false, false)
        dxDrawText("Utiliza el mouse para visualizar el vehículo", 355, 468, 235, 13, tocolor(255, 255, 255, 35), 1.00, font3, "left", "center", true, false, false, false, false)
        if isMouseInPosition(333, 490, 128, 43) and not buyVehicle and not rentVehicle then
            dxDrawImage(333, 490, 128, 43, "files/imgs/button.png", 0, 0, 0, tocolor(173, 146, 255))
            dxDrawImage(344, 509, 11, 8, "files/imgs/check.png", 0, 0, 0, tocolor(29, 20, 54))
            dxDrawText("COMPRAR VEHÍCULO", 362, 507, 87, 13, tocolor(29, 20, 54), 1.00, font4, "left", "center", false, false, false, false, false)
        else
            dxDrawImage(333, 490, 128, 43, "files/imgs/button.png", 0, 0, 0, tocolor(255, 255, 255, 1))
            dxDrawImage(344, 509, 11, 8, "files/imgs/check.png", 0, 0, 0, tocolor(255, 255, 255, 25))
            dxDrawText("COMPRAR VEHÍCULO", 362, 507, 87, 13, tocolor(255, 255, 255, 25), 1.00, font4, "left", "center", false, false, false, false, false)
        end
        if isMouseInPosition(466, 490, 153, 43) and not isMouseInPosition(590, 507, 11, 11) and not buyVehicle and not rentVehicle then
            dxDrawImage(466, 490, 153, 43, "files/imgs/button_test.png", 0, 0, 0, tocolor(173, 146, 255))
            if typeTests == "rent" then
                dxDrawImage(480, 506, 13, 13, "files/imgs/rent.png", 0, 0, 0, tocolor(29, 20, 54))
            else
                dxDrawImage(482, 505, 11, 14, "files/imgs/drive.png", 0, 0, 0, tocolor(29, 20, 54))
            end
            dxDrawText(typeTests == "rent" and "ALQUILAR VEHÍCULO" or "HACER PRUEBA DE MANEJO", 500, 507, 87, 13, tocolor(29, 20, 54), 1.00, font4, "left", "center", false, false, false, false, false)
        else
            dxDrawImage(466, 490, 153, 43, "files/imgs/button_test.png", 0, 0, 0, tocolor(255, 255, 255, 1))
            if typeTests == "rent" then
                dxDrawImage(480, 506, 13, 13, "files/imgs/rent.png", 0, 0, 0, tocolor(255, 255, 255, 25))
            else
                dxDrawImage(482, 505, 11, 14, "files/imgs/drive.png", 0, 0, 0, tocolor(255, 255, 255, 25))
            end
            dxDrawText(typeTests == "rent" and "ALQUILAR VEHÍCULO" or "HACER PRUEBA DE MANEJO", 500, 507, 87, 13, tocolor(255, 255, 255, 25), 1.00, font4, "left", "center", false, false, false, false, false)
        end
        if isMouseInPosition(590, 507, 11, 11) and not buyVehicle and not rentVehicle then
            dxDrawImage(590, 507, 11, 11, "files/imgs/refresh.png", 0, 0, 0, tocolor(173, 146, 255))
        else
            if isMouseInPosition(466, 490, 153, 43) and not buyVehicle and not rentVehicle then
                dxDrawImage(590, 507, 11, 11, "files/imgs/refresh.png", 0, 0, 0, tocolor(29, 20, 54))
            else
                dxDrawImage(590, 507, 11, 11, "files/imgs/refresh.png", 0, 0, 0, tocolor(255, 255, 255, 25))
            end
        end
        if isMouseInPosition(949, 501, 34, 34) and not buyVehicle and not rentVehicle then
            dxDrawImage(949, 501, 34, 34, "files/imgs/back.png")
        else
            dxDrawImage(949, 501, 34, 34, "files/imgs/back.png", 0, 0, 0, tocolor(255, 255, 255, 50))
        end
        if isMouseInPosition(999, 501, 34, 34) and not buyVehicle and not rentVehicle then
            dxDrawImage(999, 501, 34, 34, "files/imgs/passveh.png")
        else
            dxDrawImage(999, 501, 34, 34, "files/imgs/passveh.png", 0, 0, 0, tocolor(255, 255, 255, 50))
        end

        local cursorXT, cursorYT = getCursorPosition()

        if isCursorShowing() then
            absX = cursorXT * screen[1]
            absY = cursorYT * screen[2]
        elseif cursorIsMoving then
            cursorIsMoving = false
        else
            absX, absY = -1, -1
        end

		if cursorIsMoving then
			local rx, ry, rz = getElementRotation(vehiclePreview)
			exports.object_preview:setRotation(objectPreview, 0, 0, 360 * cursorXT)

			if absX >= screen[1] then
				setCursorPosition(0, screen[2] * 0.5)
			elseif absX <= 0 then
				setCursorPosition(screen[1], screen[2] * 0.5)
			end

            if not getKeyState("mouse1") then
				cursorIsMoving = false
				setCursorPosition(screen[1] * 0.5, screen[2] * 0.5)
                setCursorAlpha(255)
            end
        elseif (isMouseInPosition(563, 322, 310, 156) and getKeyState("mouse1")) and not buyVehicle and not rentVehicle then
            cursorIsMoving = true
            setCursorAlpha(0)
            setCursorPosition(screen[1] * 0.5, screen[2] * 0.5)
        end
        if isElement(vehiclePreview) then
            exports.object_preview:getRenderTarget()
        end

        if buyVehicle then
            dxDrawImage(300, 154, 765, 420, "files/imgs/shadow.png")
            dxDrawImage(557, 307, 275, 146, "files/imgs/buyvehicle.png")
            if isMouseInPosition(812, 321, 10, 10) then
                dxDrawImage(812, 321, 10, 10, "files/imgs/close.png", 0, 0, 0, tocolor(198, 58, 58))
            else
                dxDrawImage(812, 321, 10, 10, "files/imgs/close.png", 0, 0, 0, tocolor(255, 255, 255, 20))
            end
            dxDrawText("Confirmar compra", 590, 326, 209, 13, tocolor(255, 255, 255, 90), 1.00, font3, "left", "center", false, false, false, false, false)
            dxDrawText("Vehículo: "..config["Vehicles"][typeVehicle][vehicleSelect].Name, 573, 339, 209, 13, tocolor(255, 255, 255, 35), 1.00, font3, "left", "center", false, false, false, false, false)
            if isMouseInPosition(701, 371, 11, 11) then
                dxDrawImage(701, 371, 11, 11, "files/imgs/refresh.png", 0, 0, 0, tocolor(255, 255, 255, 50))
            else
                dxDrawImage(701, 371, 11, 11, "files/imgs/refresh.png", 0, 0, 0, tocolor(255, 255, 255, 25))
            end
            dxDrawText("Valor:", 583, 361, 28, 31, tocolor(255, 255, 255, 35), 1.00, font4, "left", "center", false, false, false, false, false)
            dxDrawText(typeMoney == "money" and "$"..formatNumber(config["Vehicles"][typeVehicle][vehicleSelect]["Price"].money) or "V$ "..formatNumber(config["Vehicles"][typeVehicle][vehicleSelect]["Price"].points), 615, 361, 84, 31, tocolor(255, 255, 255, 60), 1.00, font4, "left", "center", false, false, false, false, false)
            linha = 0
            for i, v in ipairs(config["Color's"]) do
                if (i > proxPage and linha < 3) then
                    linha = linha + 1
                    dxDrawImage((714 + 23 * linha), 368, 18, 18, "files/imgs/ellipse_colors.png", 0, 0, 0, tocolor(v[1], v[2], v[3]))
                end
            end
            if isMouseInPosition(573, 403, 239, 31) then
                dxDrawImage(573, 403, 239, 31, "files/imgs/button_buy.png", 0, 0, 0, tocolor(173, 146, 255))
                dxDrawText("Comprar vehículo", 573, 403, 239, 31, tocolor(29, 20, 54, 255), 1.00, font2, "center", "center", false, false, false, false, false)
            else
                dxDrawImage(573, 403, 239, 31, "files/imgs/button_buy.png", 0, 0, 0, tocolor(255, 255, 255, 1))
                dxDrawText("Comprar vehículo", 573, 403, 239, 31, tocolor(255, 255, 255, 25), 1.00, font2, "center", "center", false, false, false, false, false)
            end
        elseif rentVehicle then
            dxDrawImage(300, 154, 765, 420, "files/imgs/shadow.png")
            dxDrawImage(596, 306, 242, 146, "files/imgs/base_rent.png")
            if isMouseInPosition(811, 320, 10, 10) then
                dxDrawImage(811, 320, 10, 10, "files/imgs/close.png", 0, 0, 0, tocolor(198, 58, 58))
            else
                dxDrawImage(811, 320, 10, 10, "files/imgs/close.png", 0, 0, 0, tocolor(255, 255, 255, 20))
            end
            dxDrawText("Alquilar vehículo", 631, 325, 153, 13, tocolor(255, 255, 255, 90), 1.00, font3, "left", "center", false, false, false, false, false)
            dxDrawText("Vehículo: "..config["Vehicles"][typeVehicle][vehicleSelect].Name, 614, 338, 209, 13, tocolor(255, 255, 255, 35), 1.00, font3, "left", "center", false, false, false, false, false)
            dxDrawText("Valor:", 624, 360, 26, 31, tocolor(255, 255, 255, 35), 1.00, font4, "left", "center", false, false, false, false, false)
            dxDrawText("$"..formatNumber((config["Vehicles"][typeVehicle][vehicleSelect]["Price"].rent*quantityDays)), 655, 360, 57, 31, tocolor(255, 255, 255, 60), 1.00, font4, "left", "center", false, false, false, false, false)
            dxDrawText("Días:", 731, 360, 22, 31, tocolor(255, 255, 255, 35), 1.00, font4, "left", "center", false, false, false, false, false)
            dxDrawText(quantityDays, 776, 360, 22, 31, tocolor(255, 255, 255, 60), 1.00, font2, "center", "center", false, false, false, false, false)
            if isMouseInPosition(614, 402, 207, 31) then
                dxDrawImage(614, 402, 207, 31, "files/imgs/button_buy.png", 0, 0, 0, tocolor(173, 146, 255))
                dxDrawText("Alquilar vehículo", 614, 402, 207, 31, tocolor(29, 20, 54, 255), 1.00, font2, "center", "center", false, false, false, false, false)
            else
                dxDrawImage(614, 402, 207, 31, "files/imgs/button_buy.png", 0, 0, 0, tocolor(255, 255, 255, 1))
                dxDrawText("Alquilar vehículo", 614, 402, 207, 31, tocolor(255, 255, 255, 25), 1.00, font2, "center", "center", false, false, false, false, false)
            end
            if isMouseInPosition(769, 373, 5, 7) then
                dxDrawImage(769, 373, 5, 7, "files/imgs/arrow_left.png")
            else
                dxDrawImage(769, 373, 5, 7, "files/imgs/arrow_left.png", 0, 0, 0, tocolor(255, 255, 255, 50))
            end
            if isMouseInPosition(800, 373, 5, 7) then
                dxDrawImage(800, 373, 5, 7, "files/imgs/arrow_right.png")
            else
                dxDrawImage(800, 373, 5, 7, "files/imgs/arrow_right.png", 0, 0, 0, tocolor(255, 255, 255, 50))
            end
        end
    elseif window == "garage" then
        if not garage then return end
        if not garage[vehicleSelect] then return end
        local detailsJson = fromJSON(garage[vehicleSelect].dataVeh)
        dxDrawImage(340, 225, 685, 319, "files/imgs/garage.png")
        dxDrawText("Garage", 408, 258, 207, 18, tocolor(255, 255, 255, 255), 1.00, font2, "left", "center", false, false, false, false, false)
        dxDrawText("Bienvenido/a, "..puxarNome(localPlayer), 408, 274, 207, 18, tocolor(255, 255, 255, 35), 1.00, font3, "left", "center", false, false, false, false, false)
        if isMouseInPosition(634, 247, 152, 56) and not subWindow then
            dxDrawImage(634, 247, 152, 56, "files/imgs/button_save.png", 0, 0, 0, tocolor(173, 146, 255))
            dxDrawText("Presione para", 648, 258, 87, 18, tocolor(29, 20, 54), 1.00, font3, "left", "center", false, false, false, false, false)
            dxDrawText("Guardar", 648, 274, 87, 18, tocolor(29, 20, 54), 1.00, font5, "left", "center", false, false, false, false, false)
            dxDrawImage(742, 265, 19, 21, "files/imgs/garage_icon.png", 0, 0, 0, tocolor(29, 20, 54))
        else
            dxDrawImage(634, 247, 152, 56, "files/imgs/button_save.png", 0, 0, 0, tocolor(255, 255, 255, 1))
            dxDrawText("Presione para", 648, 258, 87, 18, tocolor(255, 255, 255, 35), 1.00, font3, "left", "center", false, false, false, false, false)
            dxDrawText("Guardar", 648, 274, 87, 18, tocolor(255, 255, 255, 90), 1.00, font5, "left", "center", false, false, false, false, false)
            dxDrawImage(742, 265, 19, 21, "files/imgs/garage_icon.png", 0, 0, 0, tocolor(255, 255, 255, 60))
        end
        if isMouseInPosition(790, 247, 215, 56) and not subWindow then
            dxDrawImage(790, 247, 215, 56, "files/imgs/button_withdraw.png", 0, 0, 0, tocolor(173, 146, 255))
            dxDrawText("Presione para", 803, 257, 137, 18, tocolor(29, 20, 54), 1.00, font3, "left", "center", false, false, false, false, false)
            dxDrawText("Retirar", 803, 275, 137, 18, tocolor(29, 20, 54), 1.00, font5, "left", "center", false, false, false, false, false)
            dxDrawImage(952, 267, 28, 19, "files/imgs/withdraw_icon.png", 0, 0, 0, tocolor(29, 20, 54))
        else
            dxDrawImage(790, 247, 215, 56, "files/imgs/button_withdraw.png", 0, 0, 0, tocolor(255, 255, 255, 1))
            dxDrawText("Presione para", 803, 257, 137, 18, tocolor(255, 255, 255, 35), 1.00, font3, "left", "center", false, false, false, false, false)
            dxDrawText("Retirar", 803, 275, 137, 18, tocolor(255, 255, 255, 90), 1.00, font5, "left", "center", false, false, false, false, false)
            dxDrawImage(952, 267, 28, 19, "files/imgs/withdraw_icon.png", 0, 0, 0, tocolor(255, 255, 255, 60))
        end
        dxDrawText("Vehículo - "..(detailsJson.rent and "Alquilado" or "Comprado"), 371, 332, 91, 18, tocolor(255, 255, 255, 100), 1.00, font5, "left", "center", false, false, false, false, false)
        dxDrawText(detailsJson.name, 371, 345, 114, 19, tocolor(255, 255, 255, 35), 1.00, font3, "left", "center", false, false, false, false, false)
        dxDrawText(detailsJson.plate, 371, 360, 114, 19, tocolor(173, 146, 255), 1.00, font3, "left", "center", false, false, false, false, false)
        dxDrawText("Estado del vehículo", 806, 332, 194, 18, tocolor(255, 255, 255, 90), 1.00, font5, "left", "center", false, false, false, false, false)
        dxDrawImage(806, 356, 15, 11, "files/imgs/engine.png")
        dxDrawImage(807, 376, 13, 14, "files/imgs/fuel.png")
        dxDrawText("#A1A1A1Motor: #E7E7E7"..math.ceil(detailsJson.engine/10).."%", 827, 353, 173, 18, tocolor(255, 255, 255, 255), 1.00, font3, "left", "center", false, false, false, true, false)
        dxDrawText("#A1A1A1Gasolina: #E7E7E7"..detailsJson.fuel.."%", 827, 375, 173, 18, tocolor(255, 255, 255, 255), 1.00, font3, "left", "center", false, false, false, true, false)
        if isMouseInPosition(799, 419, 103, 36) and not subWindow then
            dxDrawImage(799, 419, 103, 36, "files/imgs/button_managegarage.png", 0, 0, 0, tocolor(173, 146, 255))
            dxDrawText("Anterior", 821, 430, 67, 18, tocolor(29, 20, 54, 255), 1.00, font3, "right", "center", false, false, false, true, false)
            dxDrawImage(807, 434, 6, 10, "files/imgs/garage_arrow_left.png", 0, 0, 0, tocolor(29, 20, 54))
        else
            dxDrawImage(799, 419, 103, 36, "files/imgs/button_managegarage.png", 0, 0, 0, tocolor(255, 255, 255, 1))
            dxDrawText("Anterior", 821, 430, 67, 18, tocolor(255, 255, 255, 25), 1.00, font3, "right", "center", false, false, false, true, false)
            dxDrawImage(807, 434, 6, 10, "files/imgs/garage_arrow_left.png", 0, 0, 0, tocolor(255, 255, 255, 25))
        end
        if isMouseInPosition(905, 419, 103, 36) and not subWindow then
            dxDrawImage(905, 419, 103, 36, "files/imgs/button_managegarage.png", 0, 0, 0, tocolor(173, 146, 255))
            dxDrawText("Próximo", 918, 430, 67, 18, tocolor(29, 20, 54, 255), 1.00, font3, "left", "center", false, false, false, true, false)
            dxDrawImage(994, 434, 6, 10, "files/imgs/garage_arrow_right.png", 0, 0, 0, tocolor(29, 20, 54))
        else
            dxDrawImage(905, 419, 103, 36, "files/imgs/button_managegarage.png", 0, 0, 0, tocolor(255, 255, 255, 1))
            dxDrawText("Próximo", 918, 430, 67, 18, tocolor(255, 255, 255, 25), 1.00, font3, "left", "center", false, false, false, true, false)
            dxDrawImage(994, 434, 6, 10, "files/imgs/garage_arrow_right.png", 0, 0, 0, tocolor(255, 255, 255, 25))
        end
        linha = 0
        for i, v in ipairs(garage) do
            if (i > proxPage and linha < 4) then
                linha = linha + 1
                local jsonDetails = fromJSON(v.dataVeh)
                if vehicleSelect == i then
                    dxDrawImage((190 + 165 * linha), 463, 156, 54, "files/imgs/cage_garage_select.png")
                    dxDrawText("Vehículo - "..(jsonDetails.rent and "Alquilado" or "Comprado"), (201 + 165 * linha), 474, 138, 19, tocolor(255, 255, 255, 90), 1.00, font5, "left", "center", false, false, false, false, false)
                    dxDrawText(jsonDetails.name, (201 + 165 * linha), 490, 138, 19, tocolor(255, 255, 255, 35), 1.00, font3, "left", "center", false, false, false, false, false)
                else
                    dxDrawImage((190 + 165 * linha), 463, 156, 54, "files/imgs/cage_garage.png")
                    dxDrawText("Vehículo - "..(jsonDetails.rent and "Alquilado" or "Comprado"), (201 + 165 * linha), 474, 138, 19, tocolor(255, 255, 255, 58), 1.00, font5, "left", "center", false, false, false, false, false)
                    dxDrawText(jsonDetails.name, (201 + 165 * linha), 490, 138, 19, tocolor(255, 255, 255, 22), 1.00, font3, "left", "center", false, false, false, false, false)
                end
            end
        end
        
        local cursorXT, cursorYT = getCursorPosition()

        if isCursorShowing() then
            absX = cursorXT * screen[1]
            absY = cursorYT * screen[2]
        elseif cursorIsMoving then
            cursorIsMoving = false
        else
            absX, absY = -1, -1
        end

		if cursorIsMoving then
			local rx, ry, rz = getElementRotation(vehiclePreview)
			exports.object_preview:setRotation(objectPreview, 0, 0, 360 * cursorXT)

			if absX >= screen[1] then
				setCursorPosition(0, screen[2] * 0.5)
			elseif absX <= 0 then
				setCursorPosition(screen[1], screen[2] * 0.5)
			end

            if not getKeyState("mouse1") then
				cursorIsMoving = false
				setCursorPosition(screen[1] * 0.5, screen[2] * 0.5)
                setCursorAlpha(255)
            end
        elseif ((isMouseInPosition(470, 317, 235, 130) and getKeyState("mouse1")) and not subWindow) then
            cursorIsMoving = true
            setCursorAlpha(0)
            setCursorPosition(screen[1] * 0.5, screen[2] * 0.5)
        end
        if isElement(vehiclePreview) then
            exports.object_preview:getRenderTarget()
        end
        
        dxDrawImage(371, 409, 111, 31, "files/imgs/button_sell.png")
        if isMouseInPosition(371, 409, 111, 31) and not subWindow then
            dxDrawImage(382, 421, 15, 9, "files/imgs/sell_icon.png", 0, 0, 0, tocolor(255, 255, 255, 60))
            dxDrawText("Vender vehículo", 406, 409, 73, 31, tocolor(255, 255, 255, 60), 1.00, font4, "left", "center", false, false, false, false, false)
        else
            dxDrawImage(382, 421, 15, 9, "files/imgs/sell_icon.png", 0, 0, 0, tocolor(255, 255, 255, 30))
            dxDrawText("Vender vehículo", 406, 409, 73, 31, tocolor(255, 255, 255, 30), 1.00, font4, "left", "center", false, false, false, false, false)
        end
        if subWindow == "sell_types" then
            dxDrawImage(340, 225, 685, 319, "files/imgs/shadow.png")
            dxDrawImage(516, 305, 360, 101, "files/imgs/base_sell.png")
            dxDrawText("Vender vehículo", 551, 324, 289, 13, tocolor(255, 255, 255, 90), 1.00, font5, "left", "center", false, false, false, false, false)
            dxDrawText("Seleccione entre vender a la concesionaria o a un cliente.", 534, 337, 306, 13, tocolor(255, 255, 255, 35), 1.00, font3, "left", "center", false, false, false, false, false)
            if isMouseInPosition(534, 359, 158, 31) then
                dxDrawImage(534, 359, 158, 31, "files/imgs/b_menu_sell.png", 0, 0, 0, tocolor(255, 255, 255, 2.1))
                dxDrawImage(544, 368, 9, 11, "files/imgs/user_icon.png", 0, 0, 0, tocolor(255, 255, 255, 35))
                dxDrawText("Cliente", 560, 359, 129, 31, tocolor(255, 255, 255, 35), 1.00, font5, "left", "center", false, false, false, false, false)
            else
                dxDrawImage(534, 359, 158, 31, "files/imgs/b_menu_sell.png", 0, 0, 0, tocolor(255, 255, 255, 1.1))
                dxDrawImage(544, 368, 9, 11, "files/imgs/user_icon.png", 0, 0, 0, tocolor(255, 255, 255, 15))
                dxDrawText("Cliente", 560, 359, 129, 31, tocolor(255, 255, 255, 15), 1.00, font5, "left", "center", false, false, false, false, false)
            end
            if isMouseInPosition(700, 359, 158, 31) then
                dxDrawImage(700, 359, 158, 31, "files/imgs/b_menu_sell.png", 0, 0, 0, tocolor(255, 255, 255, 2.1))
                dxDrawImage(711, 370, 13, 9, "files/imgs/dealership_icon.png", 0, 0, 0, tocolor(255, 255, 255, 35))
                dxDrawText("Concesionaria", 728, 359, 129, 31, tocolor(255, 255, 255, 35), 1.00, font5, "left", "center", false, false, false, false, false)
            else
                dxDrawImage(700, 359, 158, 31, "files/imgs/b_menu_sell.png", 0, 0, 0, tocolor(255, 255, 255, 1.1))
                dxDrawImage(711, 370, 13, 9, "files/imgs/dealership_icon.png", 0, 0, 0, tocolor(255, 255, 255, 15))
                dxDrawText("Concesionaria", 728, 359, 129, 31, tocolor(255, 255, 255, 15), 1.00, font5, "left", "center", false, false, false, false, false)
            end
        elseif subWindow == "sell_player" then
            local jsonRemove = fromJSON(garage[vehicleSelect].dataVeh)
            dxDrawImage(340, 225, 685, 319, "files/imgs/shadow.png")
            dxDrawImage(516, 305, 360, 139, "files/imgs/sub_sell_player.png")
            dxDrawText("Vender para cliente", 551, 324, 289, 13, tocolor(255, 255, 255, 90), 1.00, font5, "left", "center", false, false, false, false, false)
            dxDrawText("Vehículo: "..jsonRemove.name, 534, 337, 306, 13, tocolor(255, 255, 255, 35), 1.00, font3, "left", "center", false, false, false, false, false)
            createEditBoxCenter(534, 359, 158, 31, tocolor(255, 255, 255, 35), font5, 1)
            createEditBoxCenter(700, 359, 158, 31, tocolor(255, 255, 255, 35), font5, 2)
            if isMouseInPosition(534, 399, 324, 31) then
                dxDrawImage(534, 399, 324, 31, "files/imgs/button_concluded_sell.png", 0, 0, 0, tocolor(173, 146, 255))
                dxDrawText("Concluir venta", 534, 399, 324, 31, tocolor(29, 20, 54, 255), 1.00, font2, "center", "center", false, false, false, false, false)
            else
                dxDrawImage(534, 399, 324, 31, "files/imgs/button_concluded_sell.png", 0, 0, 0, tocolor(255, 255, 255, 1))
                dxDrawText("Concluir venta", 534, 399, 324, 31, tocolor(255, 255, 255, 25), 1.00, font2, "center", "center", false, false, false, false, false)
            end
        elseif subWindow == "sell_dealership" then
            local jsonRemove = fromJSON(garage[vehicleSelect].dataVeh)
            priceSell = (10*jsonRemove.price/100)
            dxDrawImage(340, 225, 685, 319, "files/imgs/shadow.png")
            dxDrawImage(516, 305, 360, 139, "files/imgs/sub_sell_dealership.png")
            dxDrawText("Vender para concesionaria", 551, 324, 289, 13, tocolor(255, 255, 255, 90), 1.00, font5, "left", "center", false, false, false, false, false)
            dxDrawText("Vehículo: "..jsonRemove.name, 534, 337, 306, 13, tocolor(255, 255, 255, 35), 1.00, font3, "left", "center", false, false, false, false, false)
            dxDrawText("#656565Valor: #A1A1A1"..(jsonRemove.typeBuy == "money" and "R$" or "v$").." "..formatNumber(priceSell), 545, 359, 26, 31, tocolor(255, 255, 255, 255), 1.00, font5, "left", "center", false, false, false, true, false)
            if isMouseInPosition(534, 399, 324, 31) then
                dxDrawImage(534, 399, 324, 31, "files/imgs/button_concluded_sell.png", 0, 0, 0, tocolor(173, 146, 255))
                dxDrawText("Concluir venta", 534, 399, 324, 31, tocolor(29, 20, 54, 255), 1.00, font2, "center", "center", false, false, false, false, false)
            else
                dxDrawImage(534, 399, 324, 31, "files/imgs/button_concluded_sell.png", 0, 0, 0, tocolor(255, 255, 255, 1))
                dxDrawText("Concluir venta", 534, 399, 324, 31, tocolor(255, 255, 255, 25), 1.00, font2, "center", "center", false, false, false, false, false)
            end
        end
    elseif window == "detran" then
        dxDrawImage(419, 165, 528, 439, "files/imgs/detran.png")
        dxDrawText("Registro del Automotor", 467, 194, 279, 22, tocolor(255, 255, 255, 90), 1.00, font6, "left", "center", false, false, false, false, false)
        dxDrawText("Bienvenido/a, "..puxarNome(localPlayer), 443, 213, 279, 22, tocolor(255, 255, 255, 35), 1.00, font6, "left", "center", false, false, false, false, false)
        dxDrawText(detranTypes, 786, 187, 100, 41, tocolor(255, 255, 255, 60), 1.00, font3, "left", "center", false, false, false, false, false)
        if isMouseInPosition(896, 206, 7, 4) then
            dxDrawImage(896, 206, 7, 4, "files/imgs/arrow_down.png")
        else
            dxDrawImage(896, 206, 7, 4, "files/imgs/arrow_down.png", 0, 0, 0, tocolor(255, 255, 255, 50))
        end
        linha = 0
        for i, v in ipairs(detransTable[detranTypes]) do
            if (i > proxPage and linha < 5) then
                linha = linha + 1
                local jsonDetails = fromJSON(v.dataVeh)
                local price = (10*jsonDetails.price/100)
                dxDrawImage(435, (178 + 69 * linha), 497, 63, detranTypes == "Pagar imposto" and "files/imgs/cage_tax.png" or detranTypes == "Pagar seguro" and "files/imgs/cage_safe.png" or "files/imgs/cage_release.png")
                dxDrawText("#666666Vehículo: #A1A1A1"..jsonDetails.name, 499, (197 + 69 * linha), 218, 13, tocolor(255, 255, 255, 255), 1.00, font3, "left", "center", false, false, false, true, false)
                dxDrawText("#666666Placa del vehículo: #A1A1A1"..jsonDetails.plate, 499, (210 + 69 * linha), 218, 13, tocolor(255, 255, 255, 255), 1.00, font3, "left", "center", false, false, false, true, false)
                dxDrawText("#666666Valor: #A1A1A1$"..formatNumber(price), 738, (191 + 69 * linha), 26, 36, tocolor(255, 255, 255, 255), 1.00, font3, "left", "center", false, false, false, true, false)
                if isMouseInPosition(878, (191 + 69 * linha), 36, 36) then
                    dxDrawImage(878, (191 + 69 * linha), 36, 36, "files/imgs/detran_check.png")
                else
                    dxDrawImage(878, (191 + 69 * linha), 36, 36, "files/imgs/detran_check.png", 0, 0, 0, tocolor(255, 255, 255, 50))
                end
            end
        end
        if getKeyState("mouse1") and isCursorShowing() and (isMouseInPosition(945, cursorY, 2, 49) or rolandobarra) and (#detransTable[detranTypes] > 5) then
            cursorY,proxPage = BarraUtilExata(#detransTable[detranTypes], 5, 247, 537, "y")
            rolandobarra = true
        end
        dxDrawImage(945, cursorY, 2, 49, "files/imgs/scroll.png")
        if showWindows then
            dxDrawImage(773, 232, 150, 41, "files/imgs/cage_detran.png")
            dxDrawImage(773, 277, 150, 41, "files/imgs/cage_detran.png")
            dxDrawImage(773, 322, 150, 41, "files/imgs/cage_detran.png")
            if isMouseInPosition(773, 232, 150, 41) then
                dxDrawText("Pagar impuesto", 773, 232, 150, 41, tocolor(255, 255, 255, 100), 1.00, font6, "center", "center", false, false, false, false, false)
            else
                dxDrawText("Pagar impuesto", 773, 232, 150, 41, tocolor(255, 255, 255, 60), 1.00, font6, "center", "center", false, false, false, false, false)
            end
            if isMouseInPosition(773, 277, 150, 41) then
                dxDrawText("Pagar seguro", 773, 277, 150, 41, tocolor(255, 255, 255, 100), 1.00, font6, "center", "center", false, false, false, false, false)
            else
                dxDrawText("Pagar seguro", 773, 277, 150, 41, tocolor(255, 255, 255, 60), 1.00, font6, "center", "center", false, false, false, false, false)
            end
            if isMouseInPosition(773, 322, 150, 41) then
                dxDrawText("Liberar vehículo", 773, 322, 150, 41, tocolor(255, 255, 255, 100), 1.00, font6, "center", "center", false, false, false, false, false)
            else
                dxDrawText("Liberar vehículo", 773, 322, 150, 41, tocolor(255, 255, 255, 60), 1.00, font6, "center", "center", false, false, false, false, false)
            end
        end
    end
end

addEvent("JOAO.openDealerShip", true)
addEventHandler("JOAO.openDealerShip", root,
function(window_, indexMarker_)
    if not isEventHandlerAdded("onClientRender", root, dx) then
        window = window_
        if window == "dealership" then
            proxPage = 0
            typeMoney = "money"
            typeTests = "rent"
            typeVehicle = "car"
            vehicleSelect = 1
            quantityDays = 1
            colorSelect = {255, 255, 255}
            positionsOffsets = 0.4
            createVehicles3D({sx * 563, sy * 322, sx * 310, sy * 156}, false)
        elseif window == "garage" then
            proxPage = 0
            vehicleSelect = 1
            EditBox("add")
            select = false
            indexMarker = indexMarker_
        elseif window == "detran" then
            proxPage = 0
            cursorY = ((247)/screen[1]) * screen[1]
            detranTypes = "Pagar imposto"
        end
        subWindow = false
        addEventHandler("onClientRender", root, dx)
        showCursor(true)
    end
end)

addEventHandler("onClientClick", root,
function(_, state)
    if state == "up" then
        if isEventHandlerAdded("onClientRender", root, dx) then
            if window == "dealership" then
                if isMouseInPosition(714, 197, 37, 16) and not buyVehicle and not rentVehicle then
                    if #config["Vehicles"]["car"] > 0 then
                        typeVehicle = "car"
                        vehicleSelect = 1
                        createVehicles3D({sx * 563, sy * 322, sx * 310, sy * 156}, false)
                    else
                        notifyC("¡Ningún vehículo en esa categoría!", "error")
                    end
                end
                if isMouseInPosition(769, 197, 36, 16) and not buyVehicle and not rentVehicle then
                    if #config["Vehicles"]["motorbike"] > 0 then
                        typeVehicle = "motorbike"
                        vehicleSelect = 1
                        createVehicles3D({sx * 563, sy * 322, sx * 310, sy * 156}, false)
                    else
                        notifyC("¡Ningún vehículo en esa categoría!", "error")
                    end
                end
                if isMouseInPosition(823, 197, 62, 16) and not buyVehicle and not rentVehicle then
                    if #config["Vehicles"]["trucks"] > 0 then
                        typeVehicle = "trucks"
                        vehicleSelect = 1
                        createVehicles3D({sx * 563, sy * 322, sx * 310, sy * 156}, false)
                    else
                        notifyC("¡Ningún vehículo en esa categoría!", "error")
                    end
                end
                if isMouseInPosition(903, 197, 39, 16) and not buyVehicle and not rentVehicle then
                    if #config["Vehicles"]["boats"] > 0 then
                        typeVehicle = "boats"
                        vehicleSelect = 1
                        createVehicles3D({sx * 563, sy * 322, sx * 310, sy * 156}, false)
                    else
                        notifyC("¡Ningún vehículo en esa categoría!", "error")
                    end
                end
                if isMouseInPosition(960, 197, 71, 16) and not buyVehicle and not rentVehicle then
                    if #config["Vehicles"]["helicopters"] > 0 then
                        typeVehicle = "helicopters"
                        vehicleSelect = 1
                        createVehicles3D({sx * 563, sy * 322, sx * 310, sy * 156}, false)
                    else
                        notifyC("¡Ningún vehículo en esa categoría!", "error")
                    end
                end
                if isMouseInPosition(333, 490, 128, 43) and not buyVehicle and not rentVehicle then
                    buyVehicle = true
                    exports.object_preview:setVisible(objectPreview, false)
                end
                if isMouseInPosition(466, 490, 153, 43) and not isMouseInPosition(590, 507, 11, 11) and not buyVehicle and not rentVehicle then
                    if typeTests == "rent" then
                        rentVehicle = true
                        exports.object_preview:setVisible(objectPreview, false)
                    else
                        triggerServerEvent("JOAO.testDriveDealerShip", localPlayer, localPlayer, config["Vehicles"][typeVehicle][vehicleSelect])
                    end
                end
                if isMouseInPosition(590, 507, 11, 11) and not buyVehicle and not rentVehicle then
                    if typeTests == "rent" then
                        typeTests = "drive"
                    else
                        typeTests = "rent"
                    end
                end
                if isMouseInPosition(949, 501, 34, 34) and not buyVehicle and not rentVehicle then
                    if vehicleSelect > 1 then
                        vehicleSelect = vehicleSelect - 1
                        createVehicles3D({sx * 563, sy * 322, sx * 310, sy * 156}, false)
                    end
                end
                if isMouseInPosition(999, 501, 34, 34) and not buyVehicle and not rentVehicle then
                    if vehicleSelect < #config["Vehicles"][typeVehicle] then
                        vehicleSelect = vehicleSelect + 1
                        createVehicles3D({sx * 563, sy * 322, sx * 310, sy * 156}, false)
                    end
                end
                if buyVehicle then
                    if isMouseInPosition(812, 321, 10, 10) then
                        closeMenu()
                    end
                    if isMouseInPosition(701, 371, 11, 11) then
                        if typeMoney == "money" then
                            typeMoney = "points"
                        else
                            typeMoney = "money"
                        end
                    end
                    linha = 0
                    for i, v in ipairs(config["Color's"]) do
                        if (i > proxPage and linha < 3) then
                            linha = linha + 1
                            if isMouseInPosition((714 + 23 * linha), 368, 18, 18) then
                                setVehicleColor(vehiclePreview, v[1], v[2], v[3])
                                colorSelect = v
                                notifyC("¡Has elegido el color de tu vehículo!", "success")
                            end
                        end
                    end
                    if isMouseInPosition(573, 403, 239, 31) then
                        triggerServerEvent("JOAO.buyVehicle", localPlayer, localPlayer, config["Vehicles"][typeVehicle][vehicleSelect], colorSelect, typeVehicle, typeMoney)
                    end
                elseif rentVehicle then
                    if isMouseInPosition(811, 320, 10, 10) then
                        closeMenu()
                    end
                    if isMouseInPosition(614, 402, 207, 31) then
                        triggerServerEvent("JOAO.rentVehicle", localPlayer, localPlayer, config["Vehicles"][typeVehicle][vehicleSelect], typeVehicle, quantityDays)
                    end
                    if isMouseInPosition(769, 373, 5, 7) then
                        if quantityDays > 1 then
                            quantityDays = quantityDays - 1
                        end
                    end
                    if isMouseInPosition(800, 373, 5, 7) then
                        if quantityDays < 15 then
                            quantityDays = quantityDays + 1
                        end
                    end
                end
            elseif window == "garage" then
                select = false
                if guiGetText(edits[1]) == "" then guiSetText(edits[1], "Coloque el valor") end
                if guiGetText(edits[2]) == "" then guiSetText(edits[2], "DNI del cliente") end
                if isMouseInPosition(634, 247, 152, 56) and not subWindow then
                    triggerServerEvent("JOAO.vehicleDealerShip", localPlayer, localPlayer, garage[vehicleSelect], "save", indexMarker, vehicleSelect)
                end
                if isMouseInPosition(790, 247, 215, 56) and not subWindow then
                    triggerServerEvent("JOAO.vehicleDealerShip", localPlayer, localPlayer, garage[vehicleSelect], "withdraw", indexMarker, vehicleSelect)
                end
                if isMouseInPosition(799, 419, 103, 36) and not subWindow then
                    if vehicleSelect > 1 then
                        vehicleSelect = vehicleSelect - 1
                        createVehicles3D({sx * 470, sy * 317, sx * 235, sy * 130}, true)
                    end
                end
                if isMouseInPosition(905, 419, 103, 36) and not subWindow then
                    if vehicleSelect < #garage then
                        vehicleSelect = vehicleSelect + 1
                        createVehicles3D({sx * 470, sy * 317, sx * 235, sy * 130}, true)
                    end
                end
                if isMouseInPosition(371, 409, 111, 31) and not subWindow then
                    subWindow = "sell_types"
                    exports.object_preview:setVisible(objectPreview, false)
                end
                if subWindow == "sell_types" then
                    if isMouseInPosition(534, 359, 158, 31) then
                        subWindow = "sell_player"
                    end
                    if isMouseInPosition(700, 359, 158, 31) then
                        subWindow = "sell_dealership"
                    end
                elseif subWindow == "sell_player" then
                    if isMouseInPosition(534, 359, 158, 31) then
                        select = false
                        if guiEditSetCaretIndex(edits[1], string.len(guiGetText(edits[1]))) then
                            select = 1
                            guiBringToFront(edits[1])
                            guiSetInputMode("no_binds_when_editing") 
                            if (guiGetText(edits[1]) == "CColoque el valor") then 
                                guiSetText(edits[1], "")
                            end
                        end
                    end
                    if isMouseInPosition(700, 359, 158, 31) then
                        select = false
                        if guiEditSetCaretIndex(edits[2], string.len(guiGetText(edits[2]))) then
                            select = 2
                            guiBringToFront(edits[2])
                            guiSetInputMode("no_binds_when_editing") 
                            if (guiGetText(edits[2]) == "DNI del cliente") then 
                                guiSetText(edits[2], "")
                            end
                        end
                    end
                    if isMouseInPosition(534, 399, 324, 31) then
                        if guiGetText(edits[1]) == "" or guiGetText(edits[1]) == "CColoque el valor" then
                            notifyC("CColoque el valor.", "error")
                            return
                        end
                        if guiGetText(edits[2]) == "" or guiGetText(edits[2]) == "DNI del cliente" then
                            notifyC("Digite el DNI del cliente.", "error")
                            return
                        end
                        local value = tonumber(guiGetText(edits[1]))
                        local id = tonumber(guiGetText(edits[2]))
                        if not value then
                            notifyC("¡El valor debe ser un número!", "error")
                            return
                        end
                        if not id then
                            notifyC("¡El DNI debe ser un número!", "error")
                            return
                        end
                        if verifyNumber(value) then
                            notifyC("¡El valor está mal!", "error")
                            return
                        end
                        if verifyNumber(id) then
                            notifyC("¡El DNI está mal!", "error")
                            return
                        end
                        triggerServerEvent("JOAO.mailProposal", localPlayer, localPlayer, garage[vehicleSelect], value, id)
                    end
                elseif subWindow == "sell_dealership" then
                    if isMouseInPosition(534, 399, 324, 31) then
                        triggerServerEvent("JOAO.sellDealerShip", localPlayer, localPlayer, garage[vehicleSelect])
                    end
                end
            elseif window == "detran" then
                if rolandobarra and #detransTable[detranTypes] > 5 then 
                    rolandobarra = false
                end
                if isMouseInPosition(896, 206, 7, 4) then
                    showWindows = not showWindows
                end
                linha = 0
                for i, v in ipairs(detransTable[detranTypes]) do
                    if (i > proxPage and linha < 5) then
                        linha = linha + 1
                        if isMouseInPosition(878, (191 + 69 * linha), 36, 36) then
                            if detranTypes == "Pagar imposto" then
                                triggerServerEvent("JOAO.detranDealerShip", localPlayer, localPlayer, v.model, "tax", v.identity)
                            elseif detranTypes == "Pagar seguro" then
                                triggerServerEvent("JOAO.detranDealerShip", localPlayer, localPlayer, v.model, "safe", v.identity)
                            elseif detranTypes == "Liberar veículo" then
                                triggerServerEvent("JOAO.detranDealerShip", localPlayer, localPlayer, v.model, "release", v.identity)
                            end
                        end
                    end
                end
                if showWindows then
                    if isMouseInPosition(773, 232, 150, 41) then
                        detranTypes = "Pagar imposto"
                        showWindows = false
                        proxPage = 0
                        cursorY = ((247)/screen[1]) * screen[1]
                    end
                    if isMouseInPosition(773, 277, 150, 41) then
                        detranTypes = "Pagar seguro"
                        showWindows = false
                        proxPage = 0
                        cursorY = ((247)/screen[1]) * screen[1]
                    end
                    if isMouseInPosition(773, 322, 150, 41) then
                        detranTypes = "Liberar veículo"
                        showWindows = false
                        proxPage = 0
                        cursorY = ((247)/screen[1]) * screen[1]
                    end
                end
            end
        end
    end
end)

addEvent("JOAO.dataDealerShip", true)
addEventHandler("JOAO.dataDealerShip", root,
function(garage_, typeManage_, timestamp_)
    if typeManage_ == "garage" then
        if garage_ and #garage_ > 0 then
            garage = garage_
            createVehicles3D({sx * 470, sy * 317, sx * 235, sy * 130}, true)
        end
    elseif typeManage_ == "detran" then
        detransTable = {["Pagar imposto"] = {}, ["Pagar seguro"] = {}, ["Liberar veículo"] = {}}
        if garage_ then
            garage = garage_
            for i, v in ipairs(garage) do
                local jsonDetails = fromJSON(v.dataVeh)
                if timestamp_ >= jsonDetails.tax then
                    table.insert(detransTable["Pagar imposto"], v)
                end
                if not jsonDetails.safe then
                    table.insert(detransTable["Pagar seguro"], v)
                end
                if v.state == "Recuperar" then
                    table.insert(detransTable["Liberar veículo"], v)
                end
            end
        end
    elseif typeManage_ == "dealership" then
        if garage_ then
            stockDealerShip = garage_
        end
    end
end)

addEventHandler("onClientKey", root,
function (button, press)
	if isEventHandlerAdded("onClientRender", root, dx) then
		if button == "mouse_wheel_up" and press then
            if window == "dealership" then
                if not buyVehicle and not rentVehicle then
                    if positionsOffsets > (-1) then
                        positionsOffsets = positionsOffsets - 0.1
                        exports.object_preview:setPositionOffsets(objectPreview, 0, positionsOffsets, 0)
                    end
                elseif buyVehicle then
                    if (proxPage > 0) then
                        proxPage = proxPage - 1
                    end
                end
            elseif window == "garage" then
                if positionsOffsets > (-1) then
                    positionsOffsets = positionsOffsets - 0.1
                    exports.object_preview:setPositionOffsets(objectPreview, 0, positionsOffsets, 0)
                end
            elseif window == "detran" then
                if (proxPage > 0) then
                    proxPage = proxPage - 1
                end
                if #detransTable[detranTypes] > 5 then
                    cursorY = MoveBarraUtil(#detransTable[detranTypes], 5, 247, 537, "y", proxPage)
                end
            end
		elseif button == "mouse_wheel_down" and press then
            if window == "dealership" then
                if not buyVehicle and not rentVehicle then
                    if positionsOffsets < 1 then
                        positionsOffsets = positionsOffsets + 0.1
                        exports.object_preview:setPositionOffsets(objectPreview, 0, positionsOffsets, 0)
                    end
                elseif buyVehicle then
                    proxPage = proxPage + 1
                    if (proxPage > #config["Color's"] - 3) then
                        proxPage = #config["Color's"] - 3
                    end
                end
            elseif window == "garage" then
                if positionsOffsets < 1 then
                    positionsOffsets = positionsOffsets + 0.1
                    exports.object_preview:setPositionOffsets(objectPreview, 0, positionsOffsets, 0)
                end
            elseif window == "detran" then
                proxPage = proxPage + 1
                if (proxPage > #detransTable[detranTypes] - 5) then
                    proxPage = #detransTable[detranTypes] - 5
                end
                if #detransTable[detranTypes] > 5 then
                    cursorY = MoveBarraUtil(#detransTable[detranTypes], 5, 247, 537, "y", proxPage)
                end
            end
		end
	end
end)

function destroyPreview()
    exports.object_preview:destroyObjectPreview(objectPreview)
    if isElement(vehiclePreview) then destroyElement(vehiclePreview) end
end

function createVehicles3D(positions, garageSelect)
    if garageSelect then
        positionsOffsets = 0.4
        destroyPreview()
        local detailsJson = fromJSON(garage[vehicleSelect].dataVeh)
        vehiclePreview = createVehicle(garage[vehicleSelect].model, 0, 0, 0)
        setElementCollisionsEnabled(vehiclePreview, false)
        setVehicleColor(vehiclePreview, detailsJson.color[1], detailsJson.color[2], detailsJson.color[3])
        setElementInterior(vehiclePreview, getElementInterior(localPlayer))
        setElementDimension(vehiclePreview, getElementDimension(localPlayer))
        objectPreview = exports.object_preview:createObjectPreview(vehiclePreview, 0, 0, 0, unpack(positions))
        exports.object_preview:setPositionOffsets(objectPreview, 0, positionsOffsets, 0)
        exports.object_preview:setRotation(objectPreview, 0, 0, 230)
    else
        destroyPreview()
        vehiclePreview = createVehicle(config["Vehicles"][typeVehicle][vehicleSelect].ID, 0, 0, 0)
        setElementCollisionsEnabled(vehiclePreview, false)
        setElementInterior(vehiclePreview, getElementInterior(localPlayer))
        setElementDimension(vehiclePreview, getElementDimension(localPlayer))
        objectPreview = exports.object_preview:createObjectPreview(vehiclePreview, 0, 0, 0, sx * 563, sy * 322, sx * 310, sy * 156)
        exports.object_preview:setPositionOffsets(objectPreview, 0, positionsOffsets, 0)
        exports.object_preview:setRotation(objectPreview, 0, 0, 230)
    end
end

function closeMenu()
    if isEventHandlerAdded("onClientRender", root, dx) then
        if buyVehicle then
            buyVehicle = false
            exports.object_preview:setVisible(objectPreview, true)
            return
        elseif rentVehicle then
            rentVehicle = false
            exports.object_preview:setVisible(objectPreview, true)
            return
        elseif subWindow then
            subWindow = false
            exports.object_preview:setVisible(objectPreview, true)
        end
        EditBox("destroy")
        destroyPreview()
        removeEventHandler("onClientRender", root, dx)
        showCursor(false)
    end
end
addEvent("JOAO.closeDealerShip", true)
addEventHandler("JOAO.closeDealerShip", root, closeMenu)
bindKey("backspace", "down", closeMenu)

addEvent("JOAO.closeAllDealerShip", true)
addEventHandler("JOAO.closeAllDealerShip", root,
function()
    garageSelect = false
    garage = {}
    if isEventHandlerAdded("onClientRender", root, dx) then
        EditBox("destroy")
        destroyPreview()
        removeEventHandler("onClientRender", root, dx)
        showCursor(false)
    end
end)

function EditBox(tipo)
    if tipo == 'destroy' then
        for i=1, #edits do
            if isElement(edits[i]) then 
                destroyElement(edits[i])
            end
        end
    elseif tipo == 'add' then
        edits[1] = guiCreateEdit(-1000, -1000, 325, 50, 'CColoque el valor', false)
        guiEditSetMaxLength(edits[1], 8)
        guiSetProperty(edits[1], 'ValidationString', '[0-9]*')
        edits[2] = guiCreateEdit(-1000, -1000, 325, 50, 'DNI del cliente', false)
        guiEditSetMaxLength(edits[2], 8)
        guiSetProperty(edits[2], 'ValidationString', '[0-9]*')
	end 
end


function BarraUtilExata(TotalConteudos, MaxLinhas, posInicial, posFinal, type)
    if string.lower(type) == "x" then 
        Tela = guiGetScreenSize()
        cy = getCursorPosition()
        posInicial = (posInicial*(Tela/1366)) / Tela
        posFinal = (posFinal*(Tela/1366)) / Tela 
    elseif string.lower(type) == "y" then 
        _,Tela = guiGetScreenSize()
        _,cy = getCursorPosition()
        posInicial = (posInicial*(Tela/768)) / Tela
        posFinal = (posFinal*(Tela/768)) / Tela 
    end  
    if cy >= (posFinal) then 
        cy = (posFinal)
    elseif cy <= (posInicial) then 
        cy = (posInicial)
    end             
    DeltaG = (Tela *  (posFinal)) - (Tela * (posInicial))   
    DeltaA = (Tela *  cy) - (Tela * (posInicial))
    cursorYProgress = Tela * (cy / (Tela/768)) 
    proximaPaginaProgress = (TotalConteudos-MaxLinhas)/DeltaG*(DeltaA)
    return cursorYProgress, proximaPaginaProgress
end 

function MoveBarraUtil(TotalConteudos, MaxLinhas, posInicial, posFinal, type, proximaPaginaNovo)
    if string.lower(type) == "x" then 
        Tela = guiGetScreenSize()
        posInicial = (posInicial*(Tela/1366)) / Tela
        posFinal = (posFinal*(Tela/1366)) / Tela 
    elseif string.lower(type) == "y" then 
        _,Tela = guiGetScreenSize()
        posInicial = (posInicial*(Tela/768)) / Tela
        posFinal = (posFinal*(Tela/768)) / Tela 
    end     
    cy = (((posFinal-posInicial)/(TotalConteudos-MaxLinhas))*proximaPaginaNovo)+posInicial
    DeltaG = math.floor((Tela *  (posFinal)) - (Tela * (posInicial)))    
    DeltaA = math.floor((Tela *  cy) - (Tela * (posInicial)))
    cursorYProgress = Tela * (cy / (Tela/768)) 
    return cursorYProgress
end

function isEventHandlerAdded( sEventName, pElementAttachedTo, func )
    if type( sEventName ) == "string" and isElement( pElementAttachedTo ) and type( func ) == "function" then
        local aAttachedFunctions = getEventHandlers( sEventName, pElementAttachedTo )
        if type( aAttachedFunctions ) == "table" and #aAttachedFunctions > 0 then
            for i, v in ipairs( aAttachedFunctions ) do
                if v == func then
                    return true
                end
            end
        end
    end
    return false
end